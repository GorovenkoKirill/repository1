﻿using System;
using System.Windows;
using System.Data.Entity;
using System.Linq; // Добавляем эту директиву для FirstOrDefault

namespace GorovenkoHranitelPRO
{
    public partial class LoginWindow : Window
    {
        private readonly ГоровенкоХранительПРОEntities2 db = new ГоровенкоХранительПРОEntities2();

        public LoginWindow()
        {
            InitializeComponent();
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text.Trim();
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Заполните все поля");
                return;
            }

            try
            {
                bool sqlAuth = SqlAuth(email, password);

                if (sqlAuth)
                {
                    // Сохраняем email пользователя для дальнейшего использования
                    Application.Current.Properties["UserEmail"] = email;

                    MessageBox.Show("Авторизация успешна");
                    var mainWindow = new MainWindow();
                    mainWindow.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Неверный email или пароль");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка авторизации: {ex.Message}");
            }
        }

        private bool SqlAuth(string email, string password)
        {
            // Реализация SQL запроса
            string query = $"SELECT COUNT(*) FROM Пользователи WHERE Электронная_почта = '{email}' AND Пароль = '{password}'";
            var result = db.Database.SqlQuery<int>(query).FirstOrDefault();
            return result > 0;
        }

        private bool SpAuth(string email, string password)
        {
            // Реализация через хранимую процедуру
            // (нужно создать процедуру в БД)
            var result = db.Database.SqlQuery<int>("EXEC CheckUserAuth @Email, @Password",
                new System.Data.SqlClient.SqlParameter("@Email", email),
                new System.Data.SqlClient.SqlParameter("@Password", password)).FirstOrDefault();
            return result > 0;
        }

        private bool OrmAuth(string email, string password)
        {
            // Реализация через Entity Framework
            var user = db.Пользователи.FirstOrDefault(u => u.Электронная_почта == email && u.Пароль == password);
            return user != null;
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            var registerWindow = new RegisterWindow();
            registerWindow.Show();
            this.Close();
        }
    }
}