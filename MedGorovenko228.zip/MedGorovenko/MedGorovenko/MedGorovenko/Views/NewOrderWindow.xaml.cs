﻿using MedGorovenko.Models;
using System;
using System.Windows;
using System.Windows.Input;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Windows.Media.Imaging;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Collections.Generic;
using System.Windows.Controls;

namespace MedGorovenko.Views
{
    public partial class NewOrderWindow : Window
    {
        public User User { get; set; }
        public ObservableCollection<Patient> Patients { get; set; }
        public ObservableCollection<Service> Services { get; set; }
        public ObservableCollection<Service> SelectedServices { get; set; }

        private Patient _selectedPatient;
        private string _barcode;
        private const int BarcodeLength = 15;

        public NewOrderWindow(User user)
        {
            InitializeComponent();
            User = user;
            DataContext = this;

            Patients = new ObservableCollection<Patient>(DatabaseHelper.GetAllPatients());
            Services = new ObservableCollection<Service>(DatabaseHelper.GetAllServices());
            SelectedServices = new ObservableCollection<Service>();

            // Устанавливаем подсказку для кода пробирки (последний номер + 1)
            int lastOrderId = DatabaseHelper.GetLastOrderId();
            BarcodeTextBox.Tag = $"Рекомендуемый код: {lastOrderId + 1}";
        }

        private void BarcodeTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            _barcode = BarcodeTextBox.Text;
        }

        private void BarcodeTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (ValidateBarcode(_barcode))
                {
                    GenerateBarcodeImage(_barcode);
                }
                else
                {
                    MessageBox.Show("Неверный формат штрих-кода", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private bool ValidateBarcode(string barcode)
        {
            if (string.IsNullOrEmpty(barcode) return false;
            if (barcode.Length != BarcodeLength) return false;
            return barcode.All(char.IsDigit);
        }

        private void GenerateBarcodeImage(string barcode)
        {
            try
            {
                // Создаем изображение штрих-кода
                var barcodeImage = GenerateBarcodeBitmap(barcode);

                // Сохраняем в PDF
                SaveBarcodeToPdf(barcode, barcodeImage);

                MessageBox.Show($"Штрих-код {barcode} сгенерирован и сохранен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка генерации штрих-кода: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private Bitmap GenerateBarcodeBitmap(string barcode)
        {
            // Реализация генерации изображения штрих-кода по спецификации
            // (см. подробную реализацию ниже)
            return BarcodeGenerator.GenerateBarcode(barcode);
        }

        private void SaveBarcodeToPdf(string barcode, Bitmap barcodeImage)
        {
            string fileName = $"Barcode_{barcode}.pdf";
            string directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "LabBarcodes");

            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            string fullPath = Path.Combine(directory, fileName);

            Document document = new Document();
            PdfWriter.GetInstance(document, new FileStream(fullPath, FileMode.Create));
            document.Open();

            // Добавляем изображение штрих-кода
            using (MemoryStream ms = new MemoryStream())
            {
                barcodeImage.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(ms.ToArray());
                document.Add(img);
            }

            // Добавляем текстовое представление кода
            document.Add(new Paragraph(barcode));

            document.Close();
        }

        private void ScanButton_Click(object sender, RoutedEventArgs e)
        {
            // Имитация работы со сканером
            string scannedBarcode = SimulateBarcodeScanner();
            BarcodeTextBox.Text = scannedBarcode;
        }

        private string SimulateBarcodeScanner()
        {
            // Генерация случайного штрих-кода для тестирования
            Random random = new Random();
            StringBuilder sb = new StringBuilder();

            for (int i = 0; i < BarcodeLength; i++)
            {
                sb.Append(random.Next(0, 10));
            }

            return sb.ToString();
        }

        private void GenerateBarcodeButton_Click(object sender, RoutedEventArgs e)
        {
            int lastOrderId = DatabaseHelper.GetLastOrderId();
            string newBarcode = $"{lastOrderId + 1}{DateTime.Now:ddMMyy}{new Random().Next(100, 1000)}";

            if (newBarcode.Length < BarcodeLength)
            {
                newBarcode = newBarcode.PadRight(BarcodeLength, '0');
            }
            else if (newBarcode.Length > BarcodeLength)
            {
                newBarcode = newBarcode.Substring(0, BarcodeLength);
            }

            BarcodeTextBox.Text = newBarcode;
        }

        private void PatientSearchTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            string searchText = PatientSearchTextBox.Text.ToLower();

            if (string.IsNullOrWhiteSpace(searchText))
            {
                Patients.Clear();
                foreach (var patient in DatabaseHelper.GetAllPatients())
                {
                    Patients.Add(patient);
                }
                return;
            }

            var filteredPatients = DatabaseHelper.SearchPatients(searchText, fuzzy: true);

            Patients.Clear();
            foreach (var patient in filteredPatients)
            {
                Patients.Add(patient);
            }
        }

        private void SearchPatientButton_Click(object sender, RoutedEventArgs e)
        {
            PatientSearchTextBox_TextChanged(null, null);
        }

        private void NewPatientButton_Click(object sender, RoutedEventArgs e)
        {
            var addPatientWindow = new AddPatientWindow();
            if (addPatientWindow.ShowDialog() == true)
            {
                // Обновляем список пациентов
                Patients.Clear();
                foreach (var patient in DatabaseHelper.GetAllPatients())
                {
                    Patients.Add(patient);
                }
            }
        }

        private void PatientsListView_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (PatientsListView.SelectedItem is Patient selectedPatient)
            {
                _selectedPatient = selectedPatient;
                SelectedPatientTextBlock.Text = $"{selectedPatient.FullName}\n" +
                    $"Дата рождения: {selectedPatient.BirthDate:dd.MM.yyyy}\n" +
                    $"Полис: {selectedPatient.InsurancePolicyNumber}";
            }
        }

        private void ServiceSearchTextBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            string searchText = ServiceSearchTextBox.Text.ToLower();

            if (string.IsNullOrWhiteSpace(searchText))
            {
                Services.Clear();
                foreach (var service in DatabaseHelper.GetAllServices())
                {
                    Services.Add(service);
                }
                return;
            }

            var filteredServices = DatabaseHelper.SearchServices(searchText, fuzzy: true);

            Services.Clear();
            foreach (var service in filteredServices)
            {
                Services.Add(service);
            }
        }

        private void SearchServiceButton_Click(object sender, RoutedEventArgs e)
        {
            ServiceSearchTextBox_TextChanged(null, null);
        }

        private void ServicesListView_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            // Можно добавить логику предпросмотра выбранной услуги
        }

        private void AddServiceButton_Click(object sender, RoutedEventArgs e)
        {
            if (ServicesListView.SelectedItem is Service selectedService)
            {
                if (!SelectedServices.Any(s => s.ServiceId == selectedService.ServiceId))
                {
                    SelectedServices.Add(selectedService);
                    UpdateTotalPrice();
                }
            }
        }

        private void RemoveServiceButton_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button button && button.DataContext is Service service)
            {
                SelectedServices.Remove(service);
                UpdateTotalPrice();
            }
        }

        private void UpdateTotalPrice()
        {
            decimal total = SelectedServices.Sum(s => s.Price);
            TotalPriceTextBlock.Text = total.ToString("C");
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(_barcode))
            {
                MessageBox.Show("Введите код пробирки", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (_selectedPatient == null)
            {
                MessageBox.Show("Выберите пациента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (SelectedServices.Count == 0)
            {
                MessageBox.Show("Добавьте хотя бы одну услугу", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                // Создаем заказ
                int orderId = DatabaseHelper.CreateOrder(_selectedPatient.PatientId, _barcode, User.Id, SelectedServices.ToList());

                // Генерируем PDF с информацией о заказе
                GenerateOrderPdf(orderId, _selectedPatient, SelectedServices.ToList());

                // Генерируем ссылку с информацией о заказе
                string orderLink = GenerateOrderLink(orderId);
                SaveOrderLinkToFile(orderId, orderLink);

                MessageBox.Show("Заказ успешно создан", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при создании заказа: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void GenerateOrderPdf(int orderId, Patient patient, List<Service> services)
        {
            string fileName = $"Order_{orderId}.pdf";
            string directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "LabOrders");

            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            string fullPath = Path.Combine(directory, fileName);

            Document document = new Document();
            PdfWriter.GetInstance(document, new FileStream(fullPath, FileMode.Create));
            document.Open();

            // Заголовок
            document.Add(new Paragraph("Медицинская лаборатория №20", new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD)));
            document.Add(new Paragraph($"Заказ №{orderId}", new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD)));
            document.Add(new Paragraph($"Дата: {DateTime.Now:dd.MM.yyyy HH:mm}"));
            document.Add(new Paragraph(" "));

            // Информация о пациенте
            document.Add(new Paragraph("Пациент:", new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD)));
            document.Add(new Paragraph($"ФИО: {patient.FullName}"));
            document.Add(new Paragraph($"Дата рождения: {patient.BirthDate:dd.MM.yyyy}"));
            document.Add(new Paragraph($"Номер полиса: {patient.InsurancePolicyNumber}"));
            document.Add(new Paragraph(" "));

            // Услуги
            document.Add(new Paragraph("Услуги:", new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD)));

            PdfPTable table = new PdfPTable(3);
            table.AddCell("Код");
            table.AddCell("Название");
            table.AddCell("Цена");

            foreach (var service in services)
            {
                table.AddCell(service.Code);
                table.AddCell(service.Name);
                table.AddCell(service.Price.ToString("C"));
            }

            document.Add(table);
            document.Add(new Paragraph(" "));

            // Итого
            document.Add(new Paragraph($"Итого: {services.Sum(s => s.Price).ToString("C")}",
                new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD)));

            document.Close();
        }

        private string GenerateOrderLink(int orderId)
        {
            string data = $"дата_заказа={DateTime.Now:yyyy-MM-ddTHH:mm:ss}&номер_заказа={orderId}";
            byte[] bytes = Encoding.UTF8.GetBytes(data);
            string base64 = Convert.ToBase64String(bytes);

            return $"https://wsrussia.ru/?data={base64}";
        }

        private void SaveOrderLinkToFile(int orderId, string link)
        {
            string fileName = $"OrderLink_{orderId}.txt";
            string directory = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "LabOrderLinks");

            if (!Directory.Exists(directory))
            {
                Directory.CreateDirectory(directory);
            }

            string fullPath = Path.Combine(directory, fileName);
            File.WriteAllText(fullPath, link);
        }
    }
}