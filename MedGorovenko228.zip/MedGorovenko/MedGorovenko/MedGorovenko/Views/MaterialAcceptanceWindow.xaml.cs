﻿using MedGorovenko.Models;
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;
using System.Linq;
using Org.BouncyCastle.Asn1.X509;

namespace MedGorovenko.Views
{
    public partial class MaterialAcceptanceWindow : Window
    {
        public User User { get; set; }
        public ObservableCollection<Order> Orders { get; set; }

        public MaterialAcceptanceWindow(User user)
        {
            InitializeComponent();
            User = user;
            DataContext = this;

            LoadOrders();
        }

        private void LoadOrders()
        {
            Orders = new ObservableCollection<Order>(DatabaseHelper.GetActiveOrders());
        }

        private void NewOrderButton_Click(object sender, RoutedEventArgs e)
        {
            var newOrderWindow = new NewOrderWindow(User);
            if (newOrderWindow.ShowDialog() == true)
            {
                LoadOrders(); // Обновляем список заказов после создания нового
            }
        }
    }
}