﻿using System;

public class Order
{
    public int OrderId { get; set; }
    public int PatientId { get; set; }
    public string Barcode { get; set; }
    public DateTime CreationDate { get; set; }
    public string Status { get; set; }
    public bool IsArchived { get; set; }
}