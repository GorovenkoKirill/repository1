﻿using iTextSharp.text;
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Media;
using System.Windows;

namespace MedGorovenko.Models
{
    public static class BarcodeGenerator
    {
        // Номинальные размеры в мм (из спецификации)
        private const float SymbolHeightMm = 25.93f;
        private const float BarHeightMm = 22.85f;
        private const float LeftQuietZoneMm = 3.63f;
        private const float RightQuietZoneMm = 2.31f;
        private const float ExtendedBarExtensionMm = 1.65f;
        private const float DigitHeightMm = 2.75f;
        private const float DigitToBarGapMm = 0.165f;
        private const float BarWidthMultiplierMm = 0.15f;
        private const float ZeroBarWhiteSpaceMm = 1.35f;
        private const float BarGapMm = 0.2f;

        // Цвета (из спецификации)
        private static readonly Color[] AllowedBarColors =
        {
            Color.Black,
            Color.DarkBlue,
            Color.DarkGreen,
            Color.Brown
        };

        private static readonly Color[] AllowedBackgroundColors =
        {
            Color.White,
            Color.Yellow,
            Color.Orange,
            Color.Tan
        };

        public static Bitmap GenerateBarcode(string code)
        {
            // Проверка входных данных
            if (string.IsNullOrEmpty(code) || code.Length != 15)
                throw new ArgumentException("Код должен содержать 15 цифр");

            // Конвертируем мм в пиксели (1 мм = 3.779527559 пикселя при 96 DPI)
            const float mmToPx = 3.779527559f;

            float symbolHeightPx = SymbolHeightMm * mmToPx;
            float barHeightPx = BarHeightMm * mmToPx;
            float leftQuietZonePx = LeftQuietZoneMm * mmToPx;
            float rightQuietZonePx = RightQuietZoneMm * mmToPx;
            float extendedBarExtensionPx = ExtendedBarExtensionMm * mmToPx;
            float digitHeightPx = DigitHeightMm * mmToPx;
            float digitToBarGapPx = DigitToBarGapMm * mmToPx;
            float barWidthMultiplierPx = BarWidthMultiplierMm * mmToPx;
            float zeroBarWhiteSpacePx = ZeroBarWhiteSpaceMm * mmToPx;
            float barGapPx = BarGapMm * mmToPx;

            // Вычисляем общую ширину изображения
            float totalWidthPx = leftQuietZonePx + rightQuietZonePx;
            float[] barWidths = new float[code.Length];

            for (int i = 0; i < code.Length; i++)
            {
                int digit = int.Parse(code[i].ToString());
                if (digit == 0)
                {
                    barWidths[i] = zeroBarWhiteSpacePx;
                }
                else
                {
                    barWidths[i] = digit * barWidthMultiplierPx;
                }
                totalWidthPx += barWidths[i] + (i < code.Length - 1 ? barGapPx : 0);
            }

            // Создаем изображение
            Bitmap barcodeImage = new Bitmap((int)totalWidthPx, (int)symbolHeightPx);
            using (Graphics g = Graphics.FromImage(barcodeImage))
            {
                // Устанавливаем качество отрисовки
                g.SmoothingMode = SmoothingMode.AntiAlias;
                g.InterpolationMode = InterpolationMode.HighQualityBicubic;
                g.PixelOffsetMode = PixelOffsetMode.HighQuality;

                // Заполняем фон
                g.Clear(AllowedBackgroundColors[0]);

                // Рисуем штрих-код
                float currentX = leftQuietZonePx;

                for (int i = 0; i < code.Length; i++)
                {
                    int digit = int.Parse(code[i].ToString());
                    float barWidth = barWidths[i];

                    if (digit != 0)
                    {
                        // Определяем, нужно ли удлинять штрих (для ограничивающих знаков)
                        bool isExtendedBar = (i == 0) || (i == code.Length - 1) || (i == code.Length / 2);
                        float currentBarHeight = isExtendedBar ? barHeightPx + extendedBarExtensionPx : barHeightPx;

                        // Рисуем штрих
                        using (SolidBrush brush = new SolidBrush(AllowedBarColors[0]))
                        {
                            g.FillRectangle(brush, currentX, 0, barWidth, currentBarHeight);
                        }
                    }

                    // Рисуем цифру под штрихом
                    using (Font font = new Font("Arial", digitHeightPx, FontStyle.Regular, GraphicsUnit.Pixel))
                    using (SolidBrush brush = new SolidBrush(Color.Black))
                    {
                        float textY = barHeightPx + digitToBarGapPx;
                        g.DrawString(digit.ToString(), font, brush, currentX, textY);
                    }

                    currentX += barWidth + (i < code.Length - 1 ? barGapPx : 0);
                }
            }

            return barcodeImage;
        }
    }
}