﻿public class InsuranceCompany
{
    public int CompanyId { get; set; }
    public string Name { get; set; }
    public string Address { get; set; }
    public string Inn { get; set; }
    public string PaymentAccount { get; set; }
    public string Bik { get; set; }
}