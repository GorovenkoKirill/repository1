﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;

namespace MedGorovenko.Models
{
    public static class DatabaseHelper
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["MedicalLabDb"].ConnectionString;

        public static User AuthenticateUser(string login, string password)
        {
            User user = null;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT u.user_id, u.login, u.password, u.full_name, u.photo, u.user_type, u.last_login
                                FROM Users u
                                WHERE u.login = @Login AND u.password = @Password";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Login", login);
                command.Parameters.AddWithValue("@Password", password); // В реальном проекте используйте хэширование

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        user = new User
                        {
                            Id = Convert.ToInt32(reader["user_id"]),
                            Login = reader["login"].ToString(),
                            Password = reader["password"].ToString(),
                            FullName = reader["full_name"].ToString(),
                            PhotoPath = reader["photo"] != DBNull.Value ? reader["photo"].ToString() : null,
                            Role = (UserRole)Convert.ToInt32(reader["user_type"]),
                            LastLogin = Convert.ToDateTime(reader["last_login"])
                        };

                        // Обновляем время последнего входа
                        UpdateLastLogin(user.Id);
                    }
                }
                catch (Exception ex)
                {
                    // Логирование ошибки
                    Console.WriteLine($"Ошибка аутентификации: {ex.Message}");
                }
            }

            return user;
        }

        private static void UpdateLastLogin(int userId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"UPDATE Users 
                                SET last_login = GETDATE()
                                WHERE user_id = @UserId";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", userId);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка обновления last_login: {ex.Message}");
                }
            }
        }

        public static void LogLoginAttempt(int? userId, bool isSuccess, string ipAddress, bool captchaUsed = false)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO LoginHistory (user_id, login_attempt, login_time, ip_address, captcha_used)
                                VALUES (@UserId, @IsSuccess, GETDATE(), @IpAddress, @CaptchaUsed)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", userId ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@IsSuccess", isSuccess);
                command.Parameters.AddWithValue("@IpAddress", ipAddress);
                command.Parameters.AddWithValue("@CaptchaUsed", captchaUsed);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка записи в историю входа: {ex.Message}");
                }
            }
        }

        public static List<Order> GetActiveOrders()
        {
            List<Order> orders = new List<Order>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT order_id, patient_id, barcode, creation_date, status 
                         FROM Orders 
                         WHERE is_archived = 0
                         ORDER BY creation_date DESC";

                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        orders.Add(new Order
                        {
                            OrderId = Convert.ToInt32(reader["order_id"]),
                            PatientId = Convert.ToInt32(reader["patient_id"]),
                            Barcode = reader["barcode"].ToString(),
                            CreationDate = Convert.ToDateTime(reader["creation_date"]),
                            Status = reader["status"].ToString()
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения списка заказов: {ex.Message}");
                }
            }

            return orders;
        }

        public static int GetLastOrderId()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ISNULL(MAX(order_id), 0) FROM Orders";
                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    return Convert.ToInt32(command.ExecuteScalar());
                }
                catch
                {
                    return 0;
                }
            }
        }

        public static List<Patient> GetAllPatients()
        {
            List<Patient> patients = new List<Patient>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT patient_id, full_name, birth_date, passport_series, passport_number, 
                                phone, email, insurance_policy_number, insurance_policy_type, 
                                insurance_company_id
                         FROM Patients";

                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        patients.Add(new Patient
                        {
                            PatientId = Convert.ToInt32(reader["patient_id"]),
                            FullName = reader["full_name"].ToString(),
                            BirthDate = Convert.ToDateTime(reader["birth_date"]),
                            PassportSeries = reader["passport_series"].ToString(),
                            PassportNumber = reader["passport_number"].ToString(),
                            Phone = reader["phone"].ToString(),
                            Email = reader["email"] != DBNull.Value ? reader["email"].ToString() : null,
                            InsurancePolicyNumber = reader["insurance_policy_number"].ToString(),
                            InsurancePolicyType = reader["insurance_policy_type"].ToString(),
                            InsuranceCompanyId = reader["insurance_company_id"] != DBNull.Value ?
                                                Convert.ToInt32(reader["insurance_company_id"]) : (int?)null
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения списка пациентов: {ex.Message}");
                }
            }

            return patients;
        }

        public static List<Service> GetAllServices()
        {
            List<Service> services = new List<Service>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT service_id, code, name, price, execution_time, average_deviation
                         FROM Services";

                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        services.Add(new Service
                        {
                            ServiceId = Convert.ToInt32(reader["service_id"]),
                            Code = reader["code"].ToString(),
                            Name = reader["name"].ToString(),
                            Price = Convert.ToDecimal(reader["price"]),
                            ExecutionTime = Convert.ToInt32(reader["execution_time"]),
                            AverageDeviation = reader["average_deviation"] != DBNull.Value ?
                                             Convert.ToDecimal(reader["average_deviation"]) : (decimal?)null
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения списка услуг: {ex.Message}");
                }
            }

            return services;
        }

        public static List<InsuranceCompany> GetAllInsuranceCompanies()
        {
            List<InsuranceCompany> companies = new List<InsuranceCompany>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT company_id, name, address, inn, payment_account, bik
                         FROM InsuranceCompanies";

                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        companies.Add(new InsuranceCompany
                        {
                            CompanyId = Convert.ToInt32(reader["company_id"]),
                            Name = reader["name"].ToString(),
                            Address = reader["address"].ToString(),
                            Inn = reader["inn"].ToString(),
                            PaymentAccount = reader["payment_account"].ToString(),
                            Bik = reader["bik"].ToString()
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения списка страховых компаний: {ex.Message}");
                }
            }

            return companies;
        }

        public static List<Patient> SearchPatients(string searchText, bool fuzzy = false)
        {
            List<Patient> patients = new List<Patient>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query;

                if (fuzzy)
                {
                    // Нечеткий поиск с использованием расстояния Левенштейна
                    query = @"SELECT patient_id, full_name, birth_date, passport_series, passport_number, 
                             phone, email, insurance_policy_number, insurance_policy_type, 
                             insurance_company_id
                      FROM Patients
                      WHERE dbo.LevenshteinDistance(LOWER(full_name), LOWER(@SearchText)) <= 3";
                }
                else
                {
                    query = @"SELECT patient_id, full_name, birth_date, passport_series, passport_number, 
                             phone, email, insurance_policy_number, insurance_policy_type, 
                             insurance_company_id
                      FROM Patients
                      WHERE LOWER(full_name) LIKE '%' + LOWER(@SearchText) + '%' OR
                            LOWER(insurance_policy_number) LIKE '%' + LOWER(@SearchText) + '%' OR
                            LOWER(passport_series + passport_number) LIKE '%' + LOWER(@SearchText) + '%'";
                }

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@SearchText", searchText);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        patients.Add(new Patient
                        {
                            PatientId = Convert.ToInt32(reader["patient_id"]),
                            FullName = reader["full_name"].ToString(),
                            BirthDate = Convert.ToDateTime(reader["birth_date"]),
                            PassportSeries = reader["passport_series"].ToString(),
                            PassportNumber = reader["passport_number"].ToString(),
                            Phone = reader["phone"].ToString(),
                            Email = reader["email"] != DBNull.Value ? reader["email"].ToString() : null,
                            InsurancePolicyNumber = reader["insurance_policy_number"].ToString(),
                            InsurancePolicyType = reader["insurance_policy_type"].ToString(),
                            InsuranceCompanyId = reader["insurance_company_id"] != DBNull.Value ?
                                                Convert.ToInt32(reader["insurance_company_id"]) : (int?)null
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка поиска пациентов: {ex.Message}");
                }
            }

            return patients;
        }

        public static List<Service> SearchServices(string searchText, bool fuzzy = false)
        {
            List<Service> services = new List<Service>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query;

                if (fuzzy)
                {
                    // Нечеткий поиск с использованием расстояния Левенштейна
                    query = @"SELECT service_id, code, name, price, execution_time, average_deviation
                      FROM Services
                      WHERE dbo.LevenshteinDistance(LOWER(name), LOWER(@SearchText)) <= 3 OR
                            dbo.LevenshteinDistance(LOWER(code), LOWER(@SearchText)) <= 3";
                }
                else
                {
                    query = @"SELECT service_id, code, name, price, execution_time, average_deviation
                      FROM Services
                      WHERE LOWER(name) LIKE '%' + LOWER(@SearchText) + '%' OR
                            LOWER(code) LIKE '%' + LOWER(@SearchText) + '%'";
                }

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@SearchText", searchText);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        services.Add(new Service
                        {
                            ServiceId = Convert.ToInt32(reader["service_id"]),
                            Code = reader["code"].ToString(),
                            Name = reader["name"].ToString(),
                            Price = Convert.ToDecimal(reader["price"]),
                            ExecutionTime = Convert.ToInt32(reader["execution_time"]),
                            AverageDeviation = reader["average_deviation"] != DBNull.Value ?
                                             Convert.ToDecimal(reader["average_deviation"]) : (decimal?)null
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка поиска услуг: {ex.Message}");
                }
            }

            return services;
        }

        public static int CreateOrder(int patientId, string barcode, int userId, List<Service> services)
        {
            int orderId = 0;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    // Создаем заказ
                    string orderQuery = @"INSERT INTO Orders (patient_id, barcode, creation_date, status)
                                 VALUES (@PatientId, @Barcode, GETDATE(), 'Новый');
                                 SELECT SCOPE_IDENTITY();";

                    SqlCommand orderCommand = new SqlCommand(orderQuery, connection, transaction);
                    orderCommand.Parameters.AddWithValue("@PatientId", patientId);
                    orderCommand.Parameters.AddWithValue("@Barcode", barcode);

                    orderId = Convert.ToInt32(orderCommand.ExecuteScalar());

                    // Добавляем услуги к заказу
                    foreach (var service in services)
                    {
                        string serviceQuery = @"INSERT INTO OrderServices (order_id, service_id, status, lab_assistant_id)
                                       VALUES (@OrderId, @ServiceId, 'Назначено', @UserId)";

                        SqlCommand serviceCommand = new SqlCommand(serviceQuery, connection, transaction);
                        serviceCommand.Parameters.AddWithValue("@OrderId", orderId);
                        serviceCommand.Parameters.AddWithValue("@ServiceId", service.ServiceId);
                        serviceCommand.Parameters.AddWithValue("@UserId", userId);

                        serviceCommand.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }

            return orderId;
        }

        public static void AddPatient(Patient patient)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO Patients (login, password, full_name, birth_date, passport_series, 
                                              passport_number, phone, email, insurance_policy_number, 
                                              insurance_policy_type, insurance_company_id)
                         VALUES (@Login, @Password, @FullName, @BirthDate, @PassportSeries, @PassportNumber,
                                 @Phone, @Email, @InsurancePolicyNumber, @InsurancePolicyType, @InsuranceCompanyId)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Login", patient.Login);
                command.Parameters.AddWithValue("@Password", patient.Password);
                command.Parameters.AddWithValue("@FullName", patient.FullName);
                command.Parameters.AddWithValue("@BirthDate", patient.BirthDate);
                command.Parameters.AddWithValue("@PassportSeries", patient.PassportSeries);
                command.Parameters.AddWithValue("@PassportNumber", patient.PassportNumber);
                command.Parameters.AddWithValue("@Phone", patient.Phone);
                command.Parameters.AddWithValue("@Email", patient.Email ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@InsurancePolicyNumber", patient.InsurancePolicyNumber);
                command.Parameters.AddWithValue("@InsurancePolicyType", patient.InsurancePolicyType);
                command.Parameters.AddWithValue("@InsuranceCompanyId", patient.InsuranceCompanyId ?? (object)DBNull.Value);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("Ошибка при добавлении пациента", ex);
                }
            }
        }

    }
}