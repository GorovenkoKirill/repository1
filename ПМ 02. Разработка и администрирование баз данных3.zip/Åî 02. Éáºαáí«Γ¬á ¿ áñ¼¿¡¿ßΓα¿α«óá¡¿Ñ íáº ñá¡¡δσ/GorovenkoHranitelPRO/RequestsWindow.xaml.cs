﻿using System;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace GorovenkoHranitelPRO
{
    public partial class RequestsWindow : Window
    {
        private readonly ГоровенкоХранительПРОEntities2 db = new ГоровенкоХранительПРОEntities2();
        private string userEmail;  // Email текущего пользователя

        public RequestsWindow()
        {
            InitializeComponent();

            // Получаем email пользователя из Properties
            userEmail = Application.Current.Properties["UserEmail"] as string;

            // Проверяем, что email был получен
            if (string.IsNullOrEmpty(userEmail))
            {
                MessageBox.Show("Email пользователя не найден. Пожалуйста, войдите в систему снова.");
                // Можно вернуться на окно логина или выполнить другие действия по обработке ошибок
                var loginWindow = new LoginWindow();
                loginWindow.Show();
                this.Close();
                return;
            }

            LoadUserRequests(userEmail);
        }

        private void LoadUserRequests(string email)
        {
            try
            {
                // Получаем ID пользователя по email
                int userId = GetUserIDByEmail(email);

                // Проверяем, что ID пользователя был получен
                if (userId == -1)
                {
                    MessageBox.Show("Пользователь не найден.");
                    return;
                }

                // Загружаем заявки этого пользователя, включая статус заявки
                var requests = db.Заявки
                    .Where(r => r.ID_пользователя == userId)
                    .Select(r => new
                    {
                        r.ID_заявки,
                        r.Тип_заявки,
                        r.Дата_создания,
                        r.Дата_начала_действия,
                        r.Дата_окончания_действия,
                        r.Цель_посещения,
                        r.ID_статуса_заявки,
                        r.Причина_отказа,
                        Статус_заявки = r.Статус_заявки // Загрузка связанной сущности Статус_заявки
                    })
                    .ToList();

                RequestsDataGrid.ItemsSource = requests;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заявок: {ex.Message}");
            }
        }

        private int GetUserIDByEmail(string email)
        {
            // Ищем пользователя по email
            var user = db.Пользователи.FirstOrDefault(u => u.Электронная_почта == email);

            // Если пользователь найден, возвращаем его ID, иначе возвращаем -1
            return user?.ID_пользователя ?? -1;
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Возвращаемся в главное меню
            var mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}
