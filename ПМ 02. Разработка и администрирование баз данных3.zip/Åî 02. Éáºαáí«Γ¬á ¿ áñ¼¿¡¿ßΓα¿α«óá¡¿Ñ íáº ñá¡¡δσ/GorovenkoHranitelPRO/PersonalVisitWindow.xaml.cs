﻿using System;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using Microsoft.Win32;

namespace GorovenkoHranitelPRO
{
    public partial class PersonalVisitWindow : Window
    {
        private readonly ГоровенкоХранительПРОEntities2 db = new ГоровенкоХранительПРОEntities2();
        private byte[] passportScan = null;
        private byte[] visitorPhoto = null;

        public PersonalVisitWindow()
        {
            InitializeComponent();
            LoadDepartments();
            SetDefaultDates();
            UpdateSubmitButtonState();
        }

        private void SetDefaultDates()
        {
            StartDatePicker.SelectedDate = DateTime.Today.AddDays(1);
            EndDatePicker.SelectedDate = DateTime.Today.AddDays(2);
        }

        private void LoadDepartments()
        {
            try
            {
                //Удаляем  .Include("Отделы")
                DepartmentComboBox.ItemsSource = db.Подразделения.ToList();
                DepartmentComboBox.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки подразделений: {ex.Message}");
            }
        }

        private void DepartmentComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DepartmentComboBox.SelectedItem is Подразделения selectedDepartment)
            {
                try
                {
                    EmployeeComboBox.ItemsSource = db.Сотрудники
                        .Where(s => s.ID_подразделения == selectedDepartment.ID_подразделения)
                        .ToList()
                        .Select(s => new {
                            s.ID_сотрудника,
                            ФИО = $"{s.Фамилия} {s.Имя} {s.Отчество ?? string.Empty}"
                        });
                    EmployeeComboBox.IsEnabled = true;
                    EmployeeComboBox.SelectedIndex = 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки сотрудников: {ex.Message}");
                }
            }
        }

        private void UploadPhotoButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var openFileDialog = new OpenFileDialog
                {
                    Filter = "Image files (*.jpg, *.jpeg)|*.jpg;*.jpeg|All files (*.*)|*.*",
                    Title = "Выберите фотографию посетителя"
                };

                if (openFileDialog.ShowDialog() == true)
                {
                    var fileInfo = new FileInfo(openFileDialog.FileName);
                    if (fileInfo.Length > 4 * 1024 * 1024)
                    {
                        VisitorErrorText.Text = "Размер файла не должен превышать 4 МБ";
                        return;
                    }

                    visitorPhoto = File.ReadAllBytes(openFileDialog.FileName);

                    // Показываем превью фотографии
                    var bitmap = new BitmapImage();
                    bitmap.BeginInit();
                    bitmap.StreamSource = new MemoryStream(visitorPhoto);
                    bitmap.EndInit();
                    PhotoPreview.Source = bitmap;

                    VisitorErrorText.Text = string.Empty;
                    UpdateSubmitButtonState();
                }
            }
            catch (Exception ex)
            {
                VisitorErrorText.Text = $"Ошибка загрузки фотографии: {ex.Message}";
            }
        }

        private void UploadPassportButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var openFileDialog = new OpenFileDialog
                {
                    Filter = "PDF files (*.pdf)|*.pdf|All files (*.*)|*.*",
                    Title = "Выберите скан паспорта"
                };

                if (openFileDialog.ShowDialog() == true)
                {
                    if (Path.GetExtension(openFileDialog.FileName).ToLower() != ".pdf")
                    {
                        PassportErrorText.Text = "Файл должен быть в формате PDF";
                        return;
                    }

                    passportScan = File.ReadAllBytes(openFileDialog.FileName);
                    PassportErrorText.Text = "Скан паспорта успешно загружен";
                    UpdateSubmitButtonState();
                }
            }
            catch (Exception ex)
            {
                PassportErrorText.Text = $"Ошибка загрузки скана паспорта: {ex.Message}";
            }
        }

        private void DatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            if (StartDatePicker.SelectedDate == null || EndDatePicker.SelectedDate == null)
            {
                DateErrorText.Text = string.Empty;
                UpdateSubmitButtonState();
                return;
            }

            if (StartDatePicker.SelectedDate.Value < DateTime.Today.AddDays(1))
            {
                DateErrorText.Text = "Дата начала должна быть не раньше завтрашнего дня";
            }
            else if (StartDatePicker.SelectedDate.Value > DateTime.Today.AddDays(15))
            {
                DateErrorText.Text = "Дата начала должна быть не позже чем через 15 дней";
            }
            else if (EndDatePicker.SelectedDate.Value < StartDatePicker.SelectedDate.Value)
            {
                DateErrorText.Text = "Дата окончания не может быть раньше даты начала";
            }
            else if (EndDatePicker.SelectedDate.Value > StartDatePicker.SelectedDate.Value.AddDays(15))
            {
                DateErrorText.Text = "Период действия заявки не должен превышать 15 дней";
            }
            else
            {
                DateErrorText.Text = string.Empty;
            }

            UpdateSubmitButtonState();
        }

        private void BirthDatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            if (BirthDatePicker.SelectedDate == null)
            {
                VisitorErrorText.Text = string.Empty;
                UpdateSubmitButtonState();
                return;
            }

            if (BirthDatePicker.SelectedDate.Value.AddYears(16) > DateTime.Today)
            {
                VisitorErrorText.Text = "Посетитель должен быть старше 16 лет";
            }
            else
            {
                VisitorErrorText.Text = string.Empty;
            }

            UpdateSubmitButtonState();
        }

        private void RequiredField_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateSubmitButtonState();
        }

        private void PassportField_TextChanged(object sender, TextChangedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox == PassportSeriesTextBox && PassportSeriesTextBox.Text.Length != 4)
            {
                VisitorErrorText.Text = "Серия паспорта должна состоять из 4 цифр";
            }
            else if (textBox == PassportNumberTextBox && PassportNumberTextBox.Text.Length != 6)
            {
                VisitorErrorText.Text = "Номер паспорта должен состоять из 6 цифр";
            }
            else
            {
                VisitorErrorText.Text = string.Empty;
            }

            UpdateSubmitButtonState();
        }

        private void UpdateSubmitButtonState()
        {
            bool isValid = true;

            // Проверка дат
            if (StartDatePicker.SelectedDate == null || EndDatePicker.SelectedDate == null ||
                !string.IsNullOrEmpty(DateErrorText.Text))
            {
                isValid = false;
            }

            // Проверка обязательных полей посетителя
            if (string.IsNullOrWhiteSpace(LastNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(FirstNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(EmailTextBox.Text) ||
                string.IsNullOrWhiteSpace(NoteTextBox.Text) ||
                BirthDatePicker.SelectedDate == null ||
                string.IsNullOrWhiteSpace(PassportSeriesTextBox.Text) ||
                string.IsNullOrWhiteSpace(PassportNumberTextBox.Text) ||
                passportScan == null ||
                !string.IsNullOrEmpty(VisitorErrorText.Text))
            {
                isValid = false;
            }

            // Проверка паспорта
            if (PassportSeriesTextBox.Text.Length != 4 || PassportNumberTextBox.Text.Length != 6)
            {
                isValid = false;
            }

            SubmitButton.IsEnabled = isValid;
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                // Получаем ID текущего пользователя (предполагаем, что он авторизован)
                int userId = GetCurrentUserId();

                // Создание заявки
                var request = new Заявки
                {
                    Тип_заявки = "личная",
                    Дата_создания = DateTime.Now,
                    Дата_начала_действия = StartDatePicker.SelectedDate.Value,
                    Дата_окончания_действия = EndDatePicker.SelectedDate.Value,
                    Цель_посещения = (PurposeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString(),
                    ID_сотрудника = (EmployeeComboBox.SelectedItem as dynamic)?.ID_сотрудника,
                    ID_статуса_заявки = 1, // Предполагаем, что 1 - статус "На проверке"
                    ID_пользователя = userId > 0 ? (int?)userId : null
                };

                db.Заявки.Add(request);
                db.SaveChanges();

                // Создание посетителя
                var visitor = new Посетители
                {
                    ID_заявки = request.ID_заявки,
                    Фамилия = LastNameTextBox.Text,
                    Имя = FirstNameTextBox.Text,
                    Отчество = MiddleNameTextBox.Text,
                    Телефон = PhoneTextBox.Text,
                    Электронная_почта = EmailTextBox.Text,
                    Организация = OrganizationTextBox.Text,
                    Примечание = NoteTextBox.Text,
                    Дата_рождения = BirthDatePicker.SelectedDate.Value,
                    Серия_паспорта = PassportSeriesTextBox.Text,
                    Номер_паспорта = PassportNumberTextBox.Text,
                    Фотография = visitorPhoto,
                    Скан_паспорта = passportScan
                };

                db.Посетители.Add(visitor);
                db.SaveChanges();

                MessageBox.Show("Заявка успешно оформлена");
                var mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка оформления заявки: {ex.Message}");
            }
        }

        private bool ValidateInput()
        {
            // Все проверки уже выполнены в UpdateSubmitButtonState
            return SubmitButton.IsEnabled;
        }

        private int GetCurrentUserId()
        {
            // Здесь должна быть логика получения ID текущего пользователя
            // В реальном приложении это может быть из настроек или контекста
            return -1; // Возвращаем -1 если пользователь не авторизован
        }
    }
}