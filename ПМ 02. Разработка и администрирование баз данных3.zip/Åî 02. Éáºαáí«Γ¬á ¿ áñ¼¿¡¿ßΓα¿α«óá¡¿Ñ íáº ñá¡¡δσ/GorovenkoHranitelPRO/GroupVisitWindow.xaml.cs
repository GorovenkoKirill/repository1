﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using Microsoft.Win32;


namespace GorovenkoHranitelPRO
{
    public partial class GroupVisitWindow : Window
    {
        private readonly ГоровенкоХранительПРОEntities2 db = new ГоровенкоХранительПРОEntities2();
        private byte[] passportScan = null;
        private List<GroupVisitor> visitors = new List<GroupVisitor>();

        public GroupVisitWindow()
        {
            InitializeComponent();
            LoadDepartments();
            SetDefaultDates();
            UpdateSubmitButtonState();
        }

        private void SetDefaultDates()
        {
            StartDatePicker.SelectedDate = DateTime.Today.AddDays(1);
            EndDatePicker.SelectedDate = DateTime.Today.AddDays(2);
        }

        private void LoadDepartments()
        {
            try
            {
                //Удаляем  .Include("Отделы")
                DepartmentComboBox.ItemsSource = db.Подразделения.ToList();
                DepartmentComboBox.SelectedIndex = 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки подразделений: {ex.Message}");
            }
        }

        private void DepartmentComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (DepartmentComboBox.SelectedItem is Подразделения selectedDepartment)
            {
                try
                {
                    EmployeeComboBox.ItemsSource = db.Сотрудники
                        .Where(s => s.ID_подразделения == selectedDepartment.ID_подразделения)
                        .ToList()
                        .Select(s => new
                        {
                            s.ID_сотрудника,
                            ФИО = $"{s.Фамилия} {s.Имя} {s.Отчество ?? string.Empty}",
                            s.ID_отдела // Добавлено для последующего использования, если нужно
                        });
                    EmployeeComboBox.IsEnabled = true;
                    EmployeeComboBox.SelectedIndex = 0;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка загрузки сотрудников: {ex.Message}");
                }
            }
        }

        private void AddVisitorButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateVisitorInput()) return;

            try
            {
                var visitor = new GroupVisitor
                {
                    Номер_по_порядку = visitors.Count + 1,
                    Фамилия = LastNameTextBox.Text,
                    Имя = FirstNameTextBox.Text,
                    Отчество = MiddleNameTextBox.Text,
                    Телефон = PhoneTextBox.Text,
                    Электронная_почта = EmailTextBox.Text,
                    Контакты = $"тел. {PhoneTextBox.Text}, email: {EmailTextBox.Text}",
                    Фотография = null
                };

                visitors.Add(visitor);
                RefreshVisitorsGrid();
                ClearVisitorFields();
                UpdateSubmitButtonState();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка добавления посетителя: {ex.Message}");
            }
        }

        private bool ValidateVisitorInput()
        {
            if (string.IsNullOrWhiteSpace(LastNameTextBox.Text))
            {
                VisitorErrorText.Text = "Фамилия обязательна для заполнения";
                return false;
            }

            if (string.IsNullOrWhiteSpace(FirstNameTextBox.Text))
            {
                VisitorErrorText.Text = "Имя обязательно для заполнения";
                return false;
            }

            if (string.IsNullOrWhiteSpace(EmailTextBox.Text) || !EmailTextBox.Text.Contains("@"))
            {
                VisitorErrorText.Text = "Введите корректный email";
                return false;
            }

            if (string.IsNullOrWhiteSpace(NoteTextBox.Text))
            {
                VisitorErrorText.Text = "Примечание обязательно для заполнения";
                return false;
            }

            if (BirthDatePicker.SelectedDate == null || BirthDatePicker.SelectedDate.Value.AddYears(16) > DateTime.Today)
            {
                VisitorErrorText.Text = "Посетитель должен быть старше 16 лет";
                return false;
            }

            if (PassportSeriesTextBox.Text.Length != 4)
            {
                VisitorErrorText.Text = "Серия паспорта должна состоять из 4 цифр";
                return false;
            }

            if (PassportNumberTextBox.Text.Length != 6)
            {
                VisitorErrorText.Text = "Номер паспорта должен состоять из 6 цифр";
                return false;
            }

            VisitorErrorText.Text = string.Empty;
            return true;
        }

        private void ClearVisitorFields()
        {
            LastNameTextBox.Text = string.Empty;
            FirstNameTextBox.Text = string.Empty;
            MiddleNameTextBox.Text = string.Empty;
            PhoneTextBox.Text = string.Empty;
            EmailTextBox.Text = string.Empty;
            OrganizationTextBox.Text = string.Empty;
            NoteTextBox.Text = string.Empty;
            BirthDatePicker.SelectedDate = null;
            PassportSeriesTextBox.Text = string.Empty;
            PassportNumberTextBox.Text = string.Empty;
        }

        private void RefreshVisitorsGrid()
        {
            VisitorsDataGrid.ItemsSource = null;
            VisitorsDataGrid.ItemsSource = visitors;
        }

        private void UploadPhotoButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button == null) return;

            int visitorNumber = (int)button.Tag;
            var visitor = visitors.FirstOrDefault(v => v.Номер_по_порядку == visitorNumber);
            if (visitor == null) return;

            try
            {
                var openFileDialog = new OpenFileDialog
                {
                    Filter = "Image files (*.jpg, *.jpeg)|*.jpg;*.jpeg|All files (*.*)|*.*",
                    Title = "Выберите фотографию посетителя"
                };

                if (openFileDialog.ShowDialog() == true)
                {
                    var fileInfo = new FileInfo(openFileDialog.FileName);
                    if (fileInfo.Length > 4 * 1024 * 1024)
                    {
                        MessageBox.Show("Размер файла не должен превышать 4 МБ");
                        return;
                    }

                    visitor.Фотография = File.ReadAllBytes(openFileDialog.FileName);
                    RefreshVisitorsGrid();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки фотографии: {ex.Message}");
            }
        }

        private void RemoveVisitorButton_Click(object sender, RoutedEventArgs e)
        {
            var button = sender as Button;
            if (button == null) return;

            int visitorNumber = (int)button.Tag;
            visitors.RemoveAll(v => v.Номер_по_порядку == visitorNumber);

            // Перенумеруем оставшихся посетителей
            for (int i = 0; i < visitors.Count; i++)
            {
                visitors[i].Номер_по_порядку = i + 1;
            }

            RefreshVisitorsGrid();
            UpdateSubmitButtonState();
        }

        private void DownloadTemplateButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var saveFileDialog = new SaveFileDialog
                {
                    Filter = "Excel files (*.xlsx)|*.xlsx",
                    FileName = "Шаблон_списка_посетителей.xlsx"
                };

                if (saveFileDialog.ShowDialog() == true)
                {
                    
                    MessageBox.Show("Шаблон успешно сохранен");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка создания шаблона: {ex.Message}");
            }
        }

        private void UploadListButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var openFileDialog = new OpenFileDialog
                {
                    Filter = "Excel files (*.xlsx)|*.xlsx|All files (*.*)|*.*",
                    Title = "Выберите файл со списком посетителей"
                };

                if (openFileDialog.ShowDialog() == true)
                {
                    
                    RefreshVisitorsGrid();
                    UpdateSubmitButtonState();
                    MessageBox.Show($"Успешно загружено {visitors.Count} посетителей");
                    
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки списка: {ex.Message}");
            }
        }

        private void UploadPassportButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var openFileDialog = new OpenFileDialog
                {
                    Filter = "PDF files (*.pdf)|*.pdf|All files (*.*)|*.*",
                    Title = "Выберите скан паспорта"
                };

                if (openFileDialog.ShowDialog() == true)
                {
                    if (Path.GetExtension(openFileDialog.FileName).ToLower() != ".pdf")
                    {
                        PassportErrorText.Text = "Файл должен быть в формате PDF";
                        return;
                    }

                    passportScan = File.ReadAllBytes(openFileDialog.FileName);
                    PassportErrorText.Text = "Скан паспорта успешно загружен";
                    UpdateSubmitButtonState();
                }
            }
            catch (Exception ex)
            {
                PassportErrorText.Text = $"Ошибка загрузки скана паспорта: {ex.Message}";
            }
        }

        private void DatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            if (StartDatePicker.SelectedDate == null || EndDatePicker.SelectedDate == null)
            {
                DateErrorText.Text = string.Empty;
                UpdateSubmitButtonState();
                return;
            }

            if (StartDatePicker.SelectedDate.Value < DateTime.Today.AddDays(1))
            {
                DateErrorText.Text = "Дата начала должна быть не раньше завтрашнего дня";
            }
            else if (StartDatePicker.SelectedDate.Value > DateTime.Today.AddDays(15))
            {
                DateErrorText.Text = "Дата начала должна быть не позже чем через 15 дней";
            }
            else if (EndDatePicker.SelectedDate.Value < StartDatePicker.SelectedDate.Value)
            {
                DateErrorText.Text = "Дата окончания не может быть раньше даты начала";
            }
            else if (EndDatePicker.SelectedDate.Value > StartDatePicker.SelectedDate.Value.AddDays(15))
            {
                DateErrorText.Text = "Период действия заявки не должен превышать 15 дней";
            }
            else
            {
                DateErrorText.Text = string.Empty;
            }

            UpdateSubmitButtonState();
        }

        private void BirthDatePicker_SelectedDateChanged(object sender, SelectionChangedEventArgs e)
        {
            if (BirthDatePicker.SelectedDate == null)
            {
                VisitorErrorText.Text = string.Empty;
                UpdateSubmitButtonState();
                return;
            }

            if (BirthDatePicker.SelectedDate.Value.AddYears(16) > DateTime.Today)
            {
                VisitorErrorText.Text = "Посетитель должен быть старше 16 лет";
            }
            else
            {
                VisitorErrorText.Text = string.Empty;
            }

            UpdateSubmitButtonState();
        }

        private void RequiredField_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateSubmitButtonState();
        }

        private void PassportField_TextChanged(object sender, TextChangedEventArgs e)
        {
            var textBox = sender as TextBox;
            if (textBox == PassportSeriesTextBox && PassportSeriesTextBox.Text.Length != 4)
            {
                VisitorErrorText.Text = "Серия паспорта должна состоять из 4 цифр";
            }
            else if (textBox == PassportNumberTextBox && PassportNumberTextBox.Text.Length != 6)
            {
                VisitorErrorText.Text = "Номер паспорта должен состоять из 6 цифр";
            }
            else
            {
                VisitorErrorText.Text = string.Empty;
            }

            UpdateSubmitButtonState();
        }

        private void UpdateSubmitButtonState()
        {
            bool isValid = true;

            // Проверка дат
            if (StartDatePicker.SelectedDate == null || EndDatePicker.SelectedDate == null ||
                !string.IsNullOrEmpty(DateErrorText.Text))
            {
                isValid = false;
            }

            // Проверка обязательных полей посетителя
            if (string.IsNullOrWhiteSpace(LastNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(FirstNameTextBox.Text) ||
                string.IsNullOrWhiteSpace(EmailTextBox.Text) ||
                string.IsNullOrWhiteSpace(NoteTextBox.Text) ||
                BirthDatePicker.SelectedDate == null ||
                string.IsNullOrWhiteSpace(PassportSeriesTextBox.Text) ||
                string.IsNullOrWhiteSpace(PassportNumberTextBox.Text) ||
                passportScan == null ||
                !string.IsNullOrEmpty(VisitorErrorText.Text))
            {
                isValid = false;
            }

            // Проверка паспорта
            if (PassportSeriesTextBox.Text.Length != 4 || PassportNumberTextBox.Text.Length != 6)
            {
                isValid = false;
            }

            // Проверка количества посетителей
            if (visitors.Count < 5)
            {
                isValid = false;
            }

            SubmitButton.IsEnabled = isValid;
        }

        private void SubmitButton_Click(object sender, RoutedEventArgs e)
        {
            if (!ValidateInput()) return;

            try
            {
                // Получаем ID текущего пользователя (предполагаем, что он авторизован)
                int userId = GetCurrentUserId();

                // Создание заявки
                var request = new Заявки
                {
                    Тип_заявки = "групповая",
                    Дата_создания = DateTime.Now,
                    Дата_начала_действия = StartDatePicker.SelectedDate.Value,
                    Дата_окончания_действия = EndDatePicker.SelectedDate.Value,
                    Цель_посещения = (PurposeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString(),
                    ID_сотрудника = (EmployeeComboBox.SelectedItem as dynamic)?.ID_сотрудника,
                    ID_статуса_заявки = 1, // Предполагаем, что 1 - статус "На проверке"
                    ID_пользователя = userId > 0 ? (int?)userId : null
                };

                db.Заявки.Add(request);
                db.SaveChanges();

                // Создание основного посетителя
                var mainVisitor = new Посетители
                {
                    ID_заявки = request.ID_заявки,
                    Фамилия = LastNameTextBox.Text,
                    Имя = FirstNameTextBox.Text,
                    Отчество = MiddleNameTextBox.Text,
                    Телефон = PhoneTextBox.Text,
                    Электронная_почта = EmailTextBox.Text,
                    Организация = OrganizationTextBox.Text,
                    Примечание = NoteTextBox.Text,
                    Дата_рождения = BirthDatePicker.SelectedDate.Value,
                    Серия_паспорта = PassportSeriesTextBox.Text,
                    Номер_паспорта = PassportNumberTextBox.Text,
                    Фотография = null,
                    Скан_паспорта = passportScan
                };

                db.Посетители.Add(mainVisitor);
                db.SaveChanges();

                // Создание участников группы
                foreach (var visitor in visitors)
                {
                    var groupMember = new Участники_групп
                    {
                        ID_заявки = request.ID_заявки,
                        Номер_по_порядку = visitor.Номер_по_порядку,
                        Фамилия = visitor.Фамилия,
                        Имя = visitor.Имя,
                        Отчество = visitor.Отчество,
                        Телефон = visitor.Телефон,
                        Электронная_почта = visitor.Электронная_почта,
                        Фотография = visitor.Фотография
                    };

                    db.Участники_групп.Add(groupMember);
                }

                db.SaveChanges();

                MessageBox.Show("Заявка на групповое посещение успешно оформлена");
                var mainWindow = new MainWindow();
                mainWindow.Show();
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка оформления заявки: {ex.Message}");
            }
        }

        private bool ValidateInput()
        {
            // Все проверки уже выполнены в UpdateSubmitButtonState
            return SubmitButton.IsEnabled;
        }

        private int GetCurrentUserId()
        {
            // Здесь должна быть логика получения ID текущего пользователя
            // В реальном приложении это может быть из настроек или контекста
            return -1; // Возвращаем -1 если пользователь не авторизован
        }
    }

    public class GroupVisitor
    {
        public int Номер_по_порядку { get; set; }
        public string Фамилия { get; set; }
        public string Имя { get; set; }
        public string Отчество { get; set; }
        public string Телефон { get; set; }
        public string Электронная_почта { get; set; }
        public string Контакты { get; set; }
        public byte[] Фотография { get; set; }
    }
}