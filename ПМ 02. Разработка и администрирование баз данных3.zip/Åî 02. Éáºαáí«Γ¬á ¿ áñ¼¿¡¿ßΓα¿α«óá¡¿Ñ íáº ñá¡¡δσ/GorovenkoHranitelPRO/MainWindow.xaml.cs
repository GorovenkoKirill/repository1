﻿using System.Windows;

namespace GorovenkoHranitelPRO
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void PersonalVisitButton_Click(object sender, RoutedEventArgs e)
        {
            // Открываем окно для личного посещения
            var personalWindow = new PersonalVisitWindow();
            personalWindow.Show();
            this.Close();
        }

        private void GroupVisitButton_Click(object sender, RoutedEventArgs e)
        {
            // Открываем окно для группового посещения
            var groupWindow = new GroupVisitWindow();
            groupWindow.Show();
            this.Close();
        }

        private void ViewRequestsButton_Click(object sender, RoutedEventArgs e)
        {
            // Открываем окно просмотра заявок
            var requestsWindow = new RequestsWindow();
            requestsWindow.Show();
            this.Close();
        }
    }
}