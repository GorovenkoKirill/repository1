﻿using System;
using System.Linq;
using System.Windows;
using System.Text.RegularExpressions;

namespace GorovenkoHranitelPRO
{
    public partial class RegisterWindow : Window
    {
        private ГоровенкоХранительПРОEntities2 db = new ГоровенкоХранительПРОEntities2();

        public RegisterWindow()
        {
            InitializeComponent();
        }

        private void RegisterButton_Click(object sender, RoutedEventArgs e)
        {
            string email = EmailTextBox.Text.Trim();
            string password = PasswordBox.Password;
            string confirmPassword = ConfirmPasswordBox.Password;

            if (!ValidateInput(email, password, confirmPassword))
                return;

            // Способ 1: SQL запрос
            bool sqlReg = SqlRegister(email, password);

            // Способ 2: Хранимая процедура
            bool spReg = SpRegister(email, password);

            // Способ 3: ORM
            bool ormReg = OrmRegister(email, password);

            if (sqlReg || spReg || ormReg)
            {
                MessageBox.Show("Регистрация успешна");
                var loginWindow = new LoginWindow();
                loginWindow.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Ошибка регистрации");
            }
        }

        private bool ValidateInput(string email, string password, string confirmPassword)
        {
            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(password) || string.IsNullOrEmpty(confirmPassword))
            {
                MessageBox.Show("Заполните все поля");
                return false;
            }

            if (password != confirmPassword)
            {
                MessageBox.Show("Пароли не совпадают");
                return false;
            }

            if (!Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
            {
                MessageBox.Show("Неверный формат email");
                return false;
            }

            if (password.Length < 8 || !password.Any(char.IsUpper) ||
                !password.Any(char.IsLower) || !password.Any(char.IsDigit) ||
                !password.Any(ch => !char.IsLetterOrDigit(ch)))
            {
                MessageBox.Show("Пароль должен содержать минимум 8 символов, включая верхний и нижний регистр, цифру и спецсимвол");
                return false;
            }

            return true;
        }

        private bool SqlRegister(string email, string password)
        {
            try
            {
                string query = $"INSERT INTO Пользователи (Электронная_почта, Пароль) VALUES ('{email}', '{password}')";
                db.Database.ExecuteSqlCommand(query);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private bool SpRegister(string email, string password)
        {
            try
            {
                db.Database.ExecuteSqlCommand("EXEC RegisterUser @Email, @Password",
                    new System.Data.SqlClient.SqlParameter("@Email", email),
                    new System.Data.SqlClient.SqlParameter("@Password", password));
                return true;
            }
            catch
            {
                return false;
            }
        }

        private bool OrmRegister(string email, string password)
        {
            try
            {
                var user = new Пользователи
                {
                    Электронная_почта = email,
                    Пароль = password,
                    Дата_регистрации = DateTime.Now
                };

                db.Пользователи.Add(user);
                db.SaveChanges();
                return true;
            }
            catch
            {
                return false;
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            var loginWindow = new LoginWindow();
            loginWindow.Show();
            this.Close();
        }
    }
}