﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace MedGorovenko.Models
{
    public static class DatabaseHelper
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["MedicalLabDb"].ConnectionString;

        public static User AuthenticateUser(string login, string password)
        {
            User user = null;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT u.user_id, u.login, u.password, u.full_name, u.photo, u.user_type, u.last_login
                                FROM Users u
                                WHERE u.login = @Login AND u.password = @Password";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Login", login);
                command.Parameters.AddWithValue("@Password", password); // В реальном проекте используйте хэширование

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        user = new User
                        {
                            Id = Convert.ToInt32(reader["user_id"]),
                            Login = reader["login"].ToString(),
                            Password = reader["password"].ToString(),
                            FullName = reader["full_name"].ToString(),
                            PhotoPath = reader["photo"] != DBNull.Value ? reader["photo"].ToString() : null,
                            Role = (UserRole)Convert.ToInt32(reader["user_type"]),
                            LastLogin = Convert.ToDateTime(reader["last_login"])
                        };

                        // Обновляем время последнего входа
                        UpdateLastLogin(user.Id);
                    }
                }
                catch (Exception ex)
                {
                    // Логирование ошибки
                    Console.WriteLine($"Ошибка аутентификации: {ex.Message}");
                }
            }

            return user;
        }

        private static void UpdateLastLogin(int userId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"UPDATE Users 
                                SET last_login = GETDATE()
                                WHERE user_id = @UserId";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", userId);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка обновления last_login: {ex.Message}");
                }
            }
        }

        public static void LogLoginAttempt(int? userId, bool isSuccess, string ipAddress, bool captchaUsed = false)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO LoginHistory (user_id, login_attempt, login_time, ip_address, captcha_used)
                                VALUES (@UserId, @IsSuccess, GETDATE(), @IpAddress, @CaptchaUsed)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", userId ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@IsSuccess", isSuccess);
                command.Parameters.AddWithValue("@IpAddress", ipAddress);
                command.Parameters.AddWithValue("@CaptchaUsed", captchaUsed);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка записи в историю входа: {ex.Message}");
                }
            }
        }
    }
}