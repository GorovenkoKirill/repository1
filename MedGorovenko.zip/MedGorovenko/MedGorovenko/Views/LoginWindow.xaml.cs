﻿using MedGorovenko.Models;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Threading.Tasks;
using System.Net;
using System.Linq;

namespace MedGorovenko.Views
{
    public partial class LoginWindow : Window
    {
        private string _captchaText;
        private int _failedAttempts = 0;
        private bool _isBlocked = false;
        private string _ipAddress;

        public LoginWindow()
        {
            InitializeComponent();
            _ipAddress = GetLocalIPAddress();
        }

        private async void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            if (_isBlocked)
            {
                ShowErrorMessage("Система временно заблокирована. Попробуйте позже.");
                return;
            }

            string login = LoginTextBox.Text;
            string password = PasswordBox.Password;

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                ShowErrorMessage("Введите логин и пароль");
                return;
            }

            // Проверка CAPTCHA после первой неудачной попытки
            if (_failedAttempts > 0)
            {
                if (CaptchaTextBox.Text != _captchaText)
                {
                    ShowErrorMessage("Неверная CAPTCHA");
                    GenerateCaptcha();
                    return;
                }
            }

            var user = DatabaseHelper.AuthenticateUser(login, password);

            if (user != null)
            {
                // Успешная авторизация
                DatabaseHelper.LogLoginAttempt(user.Id, true, _ipAddress, _failedAttempts > 0);
                _failedAttempts = 0;
                ShowUserDashboard(user);
            }
            else
            {
                _failedAttempts++;
                DatabaseHelper.LogLoginAttempt(null, false, _ipAddress, _failedAttempts > 1);

                if (_failedAttempts == 1)
                {
                    // Первая неудачная попытка - показываем CAPTCHA
                    GenerateCaptcha();
                    CaptchaPanel.Visibility = Visibility.Visible;
                    ShowErrorMessage("Неверный логин или пароль. Введите CAPTCHA.");
                }
                else if (_failedAttempts > 1)
                {
                    // Блокировка на 10 секунд после неудачной попытки с CAPTCHA
                    _isBlocked = true;
                    LoginButton.IsEnabled = false;
                    ShowErrorMessage("Неверные данные. Система заблокирована на 10 секунд.");

                    await Task.Delay(10000); // 10 секунд блокировки

                    _isBlocked = false;
                    LoginButton.IsEnabled = true;
                    GenerateCaptcha();
                }
            }
        }

        private void GenerateCaptcha()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            _captchaText = new string(Enumerable.Repeat(chars, 4)
                .Select(s => s[random.Next(s.Length)]).ToArray());

            // Отрисовка CAPTCHA с шумом
            CaptchaCanvas.Children.Clear();

            // Добавляем текст CAPTCHA со случайным смещением
            for (int i = 0; i < _captchaText.Length; i++)
            {
                var textBlock = new TextBlock
                {
                    Text = _captchaText[i].ToString(),
                    FontSize = 20,
                    FontWeight = FontWeights.Bold,
                    RenderTransform = new TranslateTransform
                    {
                        X = i * 30 + random.Next(-5, 5),
                        Y = random.Next(-5, 5)
                    }
                };
                CaptchaCanvas.Children.Add(textBlock);
            }

            // Добавляем шум - случайные линии
            for (int i = 0; i < 5; i++)
            {
                var line = new Line
                {
                    X1 = random.Next(0, 120),
                    Y1 = random.Next(0, 30),
                    X2 = random.Next(0, 120),
                    Y2 = random.Next(0, 30),
                    Stroke = Brushes.Black,
                    StrokeThickness = 1
                };
                CaptchaCanvas.Children.Add(line);
            }
        }

        private void ShowPasswordCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            PasswordTextBox.Text = PasswordBox.Password;
            PasswordBox.Visibility = Visibility.Collapsed;
            PasswordTextBox.Visibility = Visibility.Visible;
        }

        private void ShowPasswordCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            PasswordBox.Password = PasswordTextBox.Text;
            PasswordTextBox.Visibility = Visibility.Collapsed;
            PasswordBox.Visibility = Visibility.Visible;
        }

        private void ShowUserDashboard(User user)
        {
            var dashboard = new DashboardWindow(user);
            dashboard.Show();
            this.Hide();

            // Для лаборантов запускаем таймер сеанса
            if (user.Role == UserRole.LabAssistant || user.Role == UserRole.ResearchAssistant)
            {
                dashboard.StartSessionTimer(TimeSpan.FromMinutes(10), TimeSpan.FromMinutes(5));
            }
        }

        private void RefreshCaptchaButton_Click(object sender, RoutedEventArgs e)
        {
            GenerateCaptcha();
        }

        private void ShowErrorMessage(string message)
        {
            ErrorMessageTextBlock.Text = message;
            ErrorMessageTextBlock.Visibility = Visibility.Visible;
        }

        private string GetLocalIPAddress()
        {
            try
            {
                string hostName = Dns.GetHostName();
                IPAddress[] addresses = Dns.GetHostAddresses(hostName);
                foreach (IPAddress address in addresses)
                {
                    if (address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                    {
                        return address.ToString();
                    }
                }
            }
            catch { }
            return "127.0.0.1";
        }
    }
}