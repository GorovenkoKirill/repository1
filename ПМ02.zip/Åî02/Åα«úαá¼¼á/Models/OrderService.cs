﻿using System;

public class OrderService
{
    public int OrderServiceId { get; set; }
    public int OrderId { get; set; }
    public int ServiceId { get; set; }
    public string Status { get; set; }
    public DateTime? ExecutionDate { get; set; }
    public int? LabAssistantId { get; set; }
    public int? AnalyzerId { get; set; }
    public string Code { get; internal set; }
    public string Name { get; internal set; }
    public string PatientName { get; internal set; }
}