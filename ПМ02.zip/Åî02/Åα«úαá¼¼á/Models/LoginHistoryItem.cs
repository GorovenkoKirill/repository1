﻿// LoginHistoryItem.cs
using System;

namespace MedGorovenko.Models
{
    public class LoginHistoryItem
    {
        public int HistoryId { get; set; }
        public DateTime LoginTime { get; set; }
        public string IpAddress { get; set; }
        public string Status { get; set; }
        public bool CaptchaUsed { get; set; }
        public string UserFullName { get; set; }
    }
}