﻿using System;

namespace MedGorovenko.Models
{
    public class BillingData
    {
        public string PatientName { get; set; }
        public string ServiceName { get; set; }
        public decimal Price { get; set; }
        public DateTime ExecutionDate { get; set; }
        public string CompanyName { get; set; }
    }
}