﻿// Models/BarcodeGenerator.cs
using System;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;

namespace MedGorovenko.Models
{
    public static class BarcodeGenerator
    {
        public static WriteableBitmap GenerateBarcode(string code, int width = 300, int height = 100)
        {
            if (string.IsNullOrEmpty(code) || code.Length != 15)
                throw new ArgumentException("Код должен содержать 15 цифр");

            var barcode = new WriteableBitmap(width, height, 96, 96, PixelFormats.Bgr32, null);

            // Заполняем фон белым цветом
            var white = new byte[] { 255, 255, 255, 255 };
            var black = new byte[] { 0, 0, 0, 255 };

            int stride = barcode.PixelWidth * 4;
            byte[] pixels = new byte[barcode.PixelHeight * stride];

            // Заполняем весь массив белым цветом
            for (int i = 0; i < pixels.Length; i += 4)
            {
                Array.Copy(white, 0, pixels, i, 4);
            }

            // Рисуем штрихи
            int barWidth = width / (code.Length * 2);
            int x = 0;

            for (int i = 0; i < code.Length; i++)
            {
                int digit = int.Parse(code[i].ToString());
                int barHeight = height * digit / 10;

                if (digit > 0)
                {
                    // Рисуем черную полосу
                    for (int y = height - barHeight; y < height; y++)
                    {
                        for (int w = 0; w < barWidth; w++)
                        {
                            int pos = (y * stride) + ((x + w) * 4);
                            if (pos + 3 < pixels.Length)
                            {
                                Array.Copy(black, 0, pixels, pos, 4);
                            }
                        }
                    }
                }

                x += barWidth * 2; // Оставляем пробел между штрихами
            }

            // Записываем пиксели в изображение
            barcode.WritePixels(new Int32Rect(0, 0, barcode.PixelWidth, barcode.PixelHeight),
                              pixels, stride, 0);

            return barcode;
        }
    }
}