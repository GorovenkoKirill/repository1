﻿using System;
using System.Collections.ObjectModel;

namespace MedGorovenko.Models
{
    public class Order
    {
        public int OrderId { get; set; }
        public string Barcode { get; set; }
        public DateTime CreationDate { get; set; }
        public string Status { get; set; }
        public ObservableCollection<Service> Services { get; set; } = new ObservableCollection<Service>();

        // Дополнительные свойства, если нужно
        public string PatientName { get; set; }
        public string PatientInsurance { get; set; }
        public int PatientId { get; internal set; }
    }
}