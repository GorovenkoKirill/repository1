﻿namespace MedGorovenko.Models
{
    public class Analyzer
    {
        public int AnalyzerId { get; set; }
        public string Name { get; set; }
        public bool IsActive { get; set; }
        public string AvailableServices { get; set; }
    }
}