﻿// Models/Service.cs
using System;

namespace MedGorovenko.Models
{
    public class Service
    {
        public int ServiceId { get; set; }
        public string Code { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public int ExecutionTime { get; set; }
        public decimal? AverageDeviation { get; set; }
        public string Status { get; internal set; }
    }
}