﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using MedGorovenko.Views;
using MongoDB.Driver.Core.Configuration;

namespace MedGorovenko.Models
{
    public static class DatabaseHelper
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["MedicalLabDb"].ConnectionString;

        public static User AuthenticateUser(string login, string password)
        {
            User user = null;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT u.user_id, u.login, u.password, u.full_name, u.photo, u.user_type, u.last_login
                                FROM Users u
                                WHERE u.login = @Login AND u.password = @Password";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Login", login);
                command.Parameters.AddWithValue("@Password", password); // В реальном проекте используйте хэширование

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        user = new User
                        {
                            Id = Convert.ToInt32(reader["user_id"]),
                            Login = reader["login"].ToString(),
                            Password = reader["password"].ToString(),
                            FullName = reader["full_name"].ToString(),
                            PhotoPath = reader["photo"] != DBNull.Value ? reader["photo"].ToString() : null,
                            Role = (UserRole)Convert.ToInt32(reader["user_type"]),
                            LastLogin = Convert.ToDateTime(reader["last_login"])
                        };

                        // Обновляем время последнего входа
                        UpdateLastLogin(user.Id);
                    }
                }
                catch (Exception ex)
                {
                    // Логирование ошибки
                    Console.WriteLine($"Ошибка аутентификации: {ex.Message}");
                }
            }

            return user;
        }

        private static void UpdateLastLogin(int userId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"UPDATE Users 
                                SET last_login = GETDATE()
                                WHERE user_id = @UserId";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", userId);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка обновления last_login: {ex.Message}");
                }
            }
        }

        public static void LogLoginAttempt(int? userId, bool isSuccess, string ipAddress, bool captchaUsed = false)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO LoginHistory (user_id, login_attempt, login_time, ip_address, captcha_used)
                                VALUES (@UserId, @IsSuccess, GETDATE(), @IpAddress, @CaptchaUsed)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", userId ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@IsSuccess", isSuccess);
                command.Parameters.AddWithValue("@IpAddress", ipAddress);
                command.Parameters.AddWithValue("@CaptchaUsed", captchaUsed);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка записи в историю входа: {ex.Message}");
                }
            }
        }

        public static List<Order> GetActiveOrders()
        {
            List<Order> orders = new List<Order>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT order_id, patient_id, barcode, creation_date, status 
                         FROM Orders 
                         WHERE is_archived = 0
                         ORDER BY creation_date DESC";

                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        orders.Add(new Order
                        {
                            OrderId = Convert.ToInt32(reader["order_id"]),
                            PatientId = Convert.ToInt32(reader["patient_id"]),
                            Barcode = reader["barcode"].ToString(),
                            CreationDate = Convert.ToDateTime(reader["creation_date"]),
                            Status = reader["status"].ToString()
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения списка заказов: {ex.Message}");
                }
            }

            return orders;
        }

        public static int GetLastOrderId()
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT ISNULL(MAX(order_id), 0) FROM Orders";
                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    return Convert.ToInt32(command.ExecuteScalar());
                }
                catch
                {
                    return 0;
                }
            }
        }

        public static List<Patient> GetAllPatients()
        {
            List<Patient> patients = new List<Patient>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT patient_id, full_name, birth_date, passport_series, passport_number, 
                                phone, email, insurance_policy_number, insurance_policy_type, 
                                insurance_company_id
                         FROM Patients";

                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        patients.Add(new Patient
                        {
                            PatientId = Convert.ToInt32(reader["patient_id"]),
                            FullName = reader["full_name"].ToString(),
                            BirthDate = Convert.ToDateTime(reader["birth_date"]),
                            PassportSeries = reader["passport_series"].ToString(),
                            PassportNumber = reader["passport_number"].ToString(),
                            Phone = reader["phone"].ToString(),
                            Email = reader["email"] != DBNull.Value ? reader["email"].ToString() : null,
                            InsurancePolicyNumber = reader["insurance_policy_number"].ToString(),
                            InsurancePolicyType = reader["insurance_policy_type"].ToString(),
                            InsuranceCompanyId = reader["insurance_company_id"] != DBNull.Value ?
                                                Convert.ToInt32(reader["insurance_company_id"]) : (int?)null
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения списка пациентов: {ex.Message}");
                }
            }

            return patients;
        }

        public static List<Service> GetAllServices()
        {
            List<Service> services = new List<Service>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT service_id, code, name, price, execution_time, average_deviation
                         FROM Services";

                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        services.Add(new Service
                        {
                            ServiceId = Convert.ToInt32(reader["service_id"]),
                            Code = reader["code"].ToString(),
                            Name = reader["name"].ToString(),
                            Price = Convert.ToDecimal(reader["price"]),
                            ExecutionTime = Convert.ToInt32(reader["execution_time"]),
                            AverageDeviation = reader["average_deviation"] != DBNull.Value ?
                                             Convert.ToDecimal(reader["average_deviation"]) : (decimal?)null
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения списка услуг: {ex.Message}");
                }
            }

            return services;
        }

        public static List<InsuranceCompany> GetAllInsuranceCompanies()
        {
            List<InsuranceCompany> companies = new List<InsuranceCompany>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT company_id, name, address, inn, payment_account, bik
                         FROM InsuranceCompanies";

                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        companies.Add(new InsuranceCompany
                        {
                            CompanyId = Convert.ToInt32(reader["company_id"]),
                            Name = reader["name"].ToString(),
                            Address = reader["address"].ToString(),
                            Inn = reader["inn"].ToString(),
                            PaymentAccount = reader["payment_account"].ToString(),
                            Bik = reader["bik"].ToString()
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения списка страховых компаний: {ex.Message}");
                }
            }

            return companies;
        }

        public static List<Patient> SearchPatients(string searchText, bool fuzzy = false)
        {
            List<Patient> patients = new List<Patient>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query;

                if (fuzzy)
                {
                    // Нечеткий поиск с использованием расстояния Левенштейна
                    query = @"SELECT patient_id, full_name, birth_date, passport_series, passport_number, 
                             phone, email, insurance_policy_number, insurance_policy_type, 
                             insurance_company_id
                      FROM Patients
                      WHERE dbo.LevenshteinDistance(LOWER(full_name), LOWER(@SearchText)) <= 3";
                }
                else
                {
                    query = @"SELECT patient_id, full_name, birth_date, passport_series, passport_number, 
                             phone, email, insurance_policy_number, insurance_policy_type, 
                             insurance_company_id
                      FROM Patients
                      WHERE LOWER(full_name) LIKE '%' + LOWER(@SearchText) + '%' OR
                            LOWER(insurance_policy_number) LIKE '%' + LOWER(@SearchText) + '%' OR
                            LOWER(passport_series + passport_number) LIKE '%' + LOWER(@SearchText) + '%'";
                }

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@SearchText", searchText);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        patients.Add(new Patient
                        {
                            PatientId = Convert.ToInt32(reader["patient_id"]),
                            FullName = reader["full_name"].ToString(),
                            BirthDate = Convert.ToDateTime(reader["birth_date"]),
                            PassportSeries = reader["passport_series"].ToString(),
                            PassportNumber = reader["passport_number"].ToString(),
                            Phone = reader["phone"].ToString(),
                            Email = reader["email"] != DBNull.Value ? reader["email"].ToString() : null,
                            InsurancePolicyNumber = reader["insurance_policy_number"].ToString(),
                            InsurancePolicyType = reader["insurance_policy_type"].ToString(),
                            InsuranceCompanyId = reader["insurance_company_id"] != DBNull.Value ?
                                                Convert.ToInt32(reader["insurance_company_id"]) : (int?)null
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка поиска пациентов: {ex.Message}");
                }
            }

            return patients;
        }

        public static List<Service> SearchServices(string searchText, bool fuzzy = false)
        {
            List<Service> services = new List<Service>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query;

                if (fuzzy)
                {
                    // Нечеткий поиск с использованием расстояния Левенштейна
                    query = @"SELECT service_id, code, name, price, execution_time, average_deviation
                      FROM Services
                      WHERE dbo.LevenshteinDistance(LOWER(name), LOWER(@SearchText)) <= 3 OR
                            dbo.LevenshteinDistance(LOWER(code), LOWER(@SearchText)) <= 3";
                }
                else
                {
                    query = @"SELECT service_id, code, name, price, execution_time, average_deviation
                      FROM Services
                      WHERE LOWER(name) LIKE '%' + LOWER(@SearchText) + '%' OR
                            LOWER(code) LIKE '%' + LOWER(@SearchText) + '%'";
                }

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@SearchText", searchText);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        services.Add(new Service
                        {
                            ServiceId = Convert.ToInt32(reader["service_id"]),
                            Code = reader["code"].ToString(),
                            Name = reader["name"].ToString(),
                            Price = Convert.ToDecimal(reader["price"]),
                            ExecutionTime = Convert.ToInt32(reader["execution_time"]),
                            AverageDeviation = reader["average_deviation"] != DBNull.Value ?
                                             Convert.ToDecimal(reader["average_deviation"]) : (decimal?)null
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка поиска услуг: {ex.Message}");
                }
            }

            return services;
        }

        public static int CreateOrder(int patientId, string barcode, int userId, List<Service> services)
        {
            int orderId = 0;

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlTransaction transaction = connection.BeginTransaction();

                try
                {
                    // Создаем заказ
                    string orderQuery = @"INSERT INTO Orders (patient_id, barcode, creation_date, status)
                                 VALUES (@PatientId, @Barcode, GETDATE(), 'Новый');
                                 SELECT SCOPE_IDENTITY();";

                    SqlCommand orderCommand = new SqlCommand(orderQuery, connection, transaction);
                    orderCommand.Parameters.AddWithValue("@PatientId", patientId);
                    orderCommand.Parameters.AddWithValue("@Barcode", barcode);

                    orderId = Convert.ToInt32(orderCommand.ExecuteScalar());

                    // Добавляем услуги к заказу
                    foreach (var service in services)
                    {
                        string serviceQuery = @"INSERT INTO OrderServices (order_id, service_id, status, lab_assistant_id)
                                       VALUES (@OrderId, @ServiceId, 'Назначено', @UserId)";

                        SqlCommand serviceCommand = new SqlCommand(serviceQuery, connection, transaction);
                        serviceCommand.Parameters.AddWithValue("@OrderId", orderId);
                        serviceCommand.Parameters.AddWithValue("@ServiceId", service.ServiceId);
                        serviceCommand.Parameters.AddWithValue("@UserId", userId);

                        serviceCommand.ExecuteNonQuery();
                    }

                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            }

            return orderId;
        }

        public static void AddPatient(Patient patient)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO Patients (login, password, full_name, birth_date, passport_series, 
                                              passport_number, phone, email, insurance_policy_number, 
                                              insurance_policy_type, insurance_company_id)
                         VALUES (@Login, @Password, @FullName, @BirthDate, @PassportSeries, @PassportNumber,
                                 @Phone, @Email, @InsurancePolicyNumber, @InsurancePolicyType, @InsuranceCompanyId)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Login", patient.Login);
                command.Parameters.AddWithValue("@Password", patient.Password);
                command.Parameters.AddWithValue("@FullName", patient.FullName);
                command.Parameters.AddWithValue("@BirthDate", patient.BirthDate);
                command.Parameters.AddWithValue("@PassportSeries", patient.PassportSeries);
                command.Parameters.AddWithValue("@PassportNumber", patient.PassportNumber);
                command.Parameters.AddWithValue("@Phone", patient.Phone);
                command.Parameters.AddWithValue("@Email", patient.Email ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@InsurancePolicyNumber", patient.InsurancePolicyNumber);
                command.Parameters.AddWithValue("@InsurancePolicyType", patient.InsurancePolicyType);
                command.Parameters.AddWithValue("@InsuranceCompanyId", patient.InsuranceCompanyId ?? (object)DBNull.Value);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("Ошибка при добавлении пациента", ex);
                }
            }
        }

        public static List<Analyzer> GetAnalyzers()
        {
            List<Analyzer> analyzers = new List<Analyzer>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT analyzer_id, name FROM Analyzers WHERE is_active = 1";

                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        analyzers.Add(new Analyzer
                        {
                            AnalyzerId = Convert.ToInt32(reader["analyzer_id"]),
                            Name = reader["name"].ToString()
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения анализаторов: {ex.Message}");
                }
            }

            return analyzers;
        }

        public static List<OrderService> GetPendingServicesForAnalyzer(int analyzerId, int userId)
        {
            List<OrderService> services = new List<OrderService>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT os.order_service_id, os.order_id, os.service_id, 
                                s.code, s.name, p.full_name as patient_name
                         FROM OrderServices os
                         JOIN Services s ON os.service_id = s.service_id
                         JOIN Orders o ON os.order_id = o.order_id
                         JOIN Patients p ON o.patient_id = p.patient_id
                         WHERE os.status = 'Назначено'
                         AND EXISTS (
                             SELECT 1 FROM LabAssistantServices las
                             WHERE las.user_id = @UserId
                             AND las.service_id = os.service_id
                         )
                         AND os.service_id IN (
                             SELECT service_id FROM Services
                             WHERE code IN (SELECT value FROM STRING_SPLIT(
                                 (SELECT available_services FROM Analyzers WHERE analyzer_id = @AnalyzerId), '|'
                             ))
                         )";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@AnalyzerId", analyzerId);
                command.Parameters.AddWithValue("@UserId", userId); // Передаем ID текущего пользователя

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        services.Add(new OrderService
                        {
                            OrderServiceId = Convert.ToInt32(reader["order_service_id"]),
                            OrderId = Convert.ToInt32(reader["order_id"]),
                            ServiceId = Convert.ToInt32(reader["service_id"]),
                            Code = reader["code"].ToString(),
                            Name = reader["name"].ToString(),
                            PatientName = reader["patient_name"].ToString()
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения услуг: {ex.Message}");
                }
            }

            return services;
        }

        public static void UpdateServiceStatus(int orderServiceId, string status, string result = null)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"UPDATE OrderServices 
                         SET status = @Status, 
                             execution_date = CASE WHEN @Status = 'Завершено' THEN GETDATE() ELSE execution_date END,
                             result = @Result
                         WHERE order_service_id = @OrderServiceId";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@OrderServiceId", orderServiceId);
                command.Parameters.AddWithValue("@Status", status);
                command.Parameters.AddWithValue("@Result", result ?? (object)DBNull.Value);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка обновления статуса услуги: {ex.Message}");
                }
            }
        }

        public static List<BillingData> GetBillingData(int companyId, DateTime startDate, DateTime endDate)
        {
            List<BillingData> billingData = new List<BillingData>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT p.full_name, s.name as service_name, s.price, 
                                os.execution_date, ic.name as company_name
                         FROM OrderServices os
                         JOIN Orders o ON os.order_id = o.order_id
                         JOIN Patients p ON o.patient_id = p.patient_id
                         JOIN Services s ON os.service_id = s.service_id
                         LEFT JOIN InsuranceCompanies ic ON p.insurance_company_id = ic.company_id
                         WHERE p.insurance_company_id = @CompanyId
                         AND os.execution_date BETWEEN @StartDate AND @EndDate
                         AND os.status = 'Выполнена'";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@CompanyId", companyId);
                command.Parameters.AddWithValue("@StartDate", startDate);
                command.Parameters.AddWithValue("@EndDate", endDate);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        billingData.Add(new BillingData
                        {
                            PatientName = reader["full_name"].ToString(),
                            ServiceName = reader["service_name"].ToString(),
                            Price = Convert.ToDecimal(reader["price"]),
                            ExecutionDate = Convert.ToDateTime(reader["execution_date"]),
                            CompanyName = reader["company_name"].ToString()
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения данных для счета: {ex.Message}");
                }
            }

            return billingData;
        }

        public static Service GetServiceById(int serviceId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT * FROM Services WHERE service_id = @ServiceId";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@ServiceId", serviceId);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        return new Service
                        {
                            ServiceId = Convert.ToInt32(reader["service_id"]),
                            Code = reader["code"].ToString(),
                            Name = reader["name"].ToString(),
                            Price = Convert.ToDecimal(reader["price"]),
                            ExecutionTime = Convert.ToInt32(reader["execution_time"]),
                            AverageDeviation = reader["average_deviation"] != DBNull.Value ?
                                             Convert.ToDecimal(reader["average_deviation"]) : (decimal?)null
                        };
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения услуги: {ex.Message}");
                }
            }

            return null;
        }

        public static List<BillingReportItem> GetBillingReportData(int? companyId, DateTime startDate, DateTime endDate)
        {
            var reportData = new List<BillingReportItem>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT o.creation_date as Date, 
                                ic.name as CompanyName,
                                p.full_name as PatientName,
                                s.name as ServiceName,
                                s.price as Price
                         FROM OrderServices os
                         JOIN Orders o ON os.order_id = o.order_id
                         JOIN Patients p ON o.patient_id = p.patient_id
                         JOIN Services s ON os.service_id = s.service_id
                         LEFT JOIN InsuranceCompanies ic ON p.insurance_company_id = ic.company_id
                         WHERE os.status = 'Завершено'
                         AND os.execution_date BETWEEN @StartDate AND @EndDate
                         AND (@CompanyId IS NULL OR p.insurance_company_id = @CompanyId)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StartDate", startDate);
                command.Parameters.AddWithValue("@EndDate", endDate);
                command.Parameters.AddWithValue("@CompanyId", companyId ?? (object)DBNull.Value);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        reportData.Add(new BillingReportItem
                        {
                            Date = Convert.ToDateTime(reader["Date"]),
                            CompanyName = reader["CompanyName"].ToString(),
                            PatientName = reader["PatientName"].ToString(),
                            ServiceName = reader["ServiceName"].ToString(),
                            Price = Convert.ToDecimal(reader["Price"])
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения данных отчета: {ex.Message}");
                }
            }

            return reportData;
        }

        public static List<Order> GetActiveOrdersWithServices()
        {
            var orders = new List<Order>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Основной запрос для заказов
                var orderCommand = new SqlCommand(
                    @"SELECT o.order_id, o.barcode, o.creation_date, o.status, 
                     p.full_name, p.insurance_policy_number
              FROM Orders o
              JOIN Patients p ON o.patient_id = p.patient_id
              WHERE o.is_archived = 0",
                    connection);

                using (var reader = orderCommand.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        orders.Add(new Order
                        {
                            OrderId = reader.GetInt32(0),
                            Barcode = reader.GetString(1),
                            CreationDate = reader.GetDateTime(2),
                            Status = reader.GetString(3),
                            PatientName = reader.GetString(4),
                            PatientInsurance = reader.GetString(5)
                        });
                    }
                }

                // Загрузка услуг для каждого заказа
                foreach (var order in orders)
                {
                    var servicesCommand = new SqlCommand(
                        @"SELECT s.service_id, s.code, s.name, s.price, os.status 
                  FROM OrderServices os
                  JOIN Services s ON os.service_id = s.service_id
                  WHERE os.order_id = @orderId",
                        connection);

                    servicesCommand.Parameters.AddWithValue("@orderId", order.OrderId);

                    using (var reader = servicesCommand.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            order.Services.Add(new Service
                            {
                                ServiceId = reader.GetInt32(0),
                                Code = reader.GetString(1),
                                Name = reader.GetString(2),
                                Price = reader.GetDecimal(3),
                                Status = reader.GetString(4)
                            });
                        }
                    }
                }
            }

            return orders;
        }

        // Добавляем в класс DatabaseHelper следующие методы:

        public static List<User> GetAllUsers()
        {
            List<User> users = new List<User>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT user_id, login, password, full_name, photo, user_type, last_login
                         FROM Users
                         ORDER BY full_name";

                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        users.Add(new User
                        {
                            Id = Convert.ToInt32(reader["user_id"]),
                            Login = reader["login"].ToString(),
                            Password = reader["password"].ToString(),
                            FullName = reader["full_name"].ToString(),
                            PhotoPath = reader["photo"] != DBNull.Value ? reader["photo"].ToString() : null,
                            Role = (UserRole)Convert.ToInt32(reader["user_type"]),
                            LastLogin = reader["last_login"] != DBNull.Value ?
                                       Convert.ToDateTime(reader["last_login"]) : DateTime.MinValue
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения списка пользователей: {ex.Message}");
                }
            }

            return users;
        }

        public static List<User> SearchUsers(string searchText)
        {
            List<User> users = new List<User>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT user_id, login, password, full_name, photo, user_type, last_login
                         FROM Users
                         WHERE LOWER(login) LIKE '%' + LOWER(@SearchText) + '%' OR
                               LOWER(full_name) LIKE '%' + LOWER(@SearchText) + '%'";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@SearchText", searchText);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        users.Add(new User
                        {
                            Id = Convert.ToInt32(reader["user_id"]),
                            Login = reader["login"].ToString(),
                            Password = reader["password"].ToString(),
                            FullName = reader["full_name"].ToString(),
                            PhotoPath = reader["photo"] != DBNull.Value ? reader["photo"].ToString() : null,
                            Role = (UserRole)Convert.ToInt32(reader["user_type"]),
                            LastLogin = reader["last_login"] != DBNull.Value ?
                                       Convert.ToDateTime(reader["last_login"]) : DateTime.MinValue
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка поиска пользователей: {ex.Message}");
                }
            }

            return users;
        }

        public static void AddUser(User user)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"INSERT INTO Users (login, password, full_name, user_type)
                         VALUES (@Login, @Password, @FullName, @UserType)";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@Login", user.Login);
                command.Parameters.AddWithValue("@Password", user.Password);
                command.Parameters.AddWithValue("@FullName", user.FullName);
                command.Parameters.AddWithValue("@UserType", (int)user.Role);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("Ошибка при добавлении пользователя", ex);
                }
            }
        }

        public static void UpdateUser(User user)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"UPDATE Users 
                         SET login = @Login, 
                             password = @Password, 
                             full_name = @FullName, 
                             user_type = @UserType
                         WHERE user_id = @UserId";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", user.Id);
                command.Parameters.AddWithValue("@Login", user.Login);
                command.Parameters.AddWithValue("@Password", user.Password);
                command.Parameters.AddWithValue("@FullName", user.FullName);
                command.Parameters.AddWithValue("@UserType", (int)user.Role);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("Ошибка при обновлении пользователя", ex);
                }
            }
        }

        public static void DeleteUser(int userId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Users WHERE user_id = @UserId";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", userId);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("Ошибка при удалении пользователя", ex);
                }
            }
        }

        public static List<Analyzer> GetAnalyzers(bool includeInactive = false)
        {
            List<Analyzer> analyzers = new List<Analyzer>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT analyzer_id, name, is_active FROM Analyzers";
                if (!includeInactive) query += " WHERE is_active = 1";

                SqlCommand command = new SqlCommand(query, connection);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        analyzers.Add(new Analyzer
                        {
                            AnalyzerId = Convert.ToInt32(reader["analyzer_id"]),
                            Name = reader["name"].ToString(),
                            IsActive = Convert.ToBoolean(reader["is_active"])
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения списка анализаторов: {ex.Message}");
                }
            }

            return analyzers;
        }

        public static List<Analyzer> SearchAnalyzers(string searchText)
        {
            List<Analyzer> analyzers = new List<Analyzer>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT analyzer_id, name, is_active 
                         FROM Analyzers
                         WHERE LOWER(name) LIKE '%' + LOWER(@SearchText) + '%'";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@SearchText", searchText);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        analyzers.Add(new Analyzer
                        {
                            AnalyzerId = Convert.ToInt32(reader["analyzer_id"]),
                            Name = reader["name"].ToString(),
                            IsActive = Convert.ToBoolean(reader["is_active"])
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка поиска анализаторов: {ex.Message}");
                }
            }

            return analyzers;
        }

        public static void DeleteAnalyzer(int analyzerId)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "DELETE FROM Analyzers WHERE analyzer_id = @AnalyzerId";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@AnalyzerId", analyzerId);

                try
                {
                    connection.Open();
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    throw new Exception("Ошибка при удалении анализатора", ex);
                }
            }
        }

        public static List<LoginHistoryItem> GetLoginHistory(DateTime startDate, DateTime endDate, int? userId, bool? isSuccess)
        {
            List<LoginHistoryItem> history = new List<LoginHistoryItem>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = @"SELECT lh.history_id, lh.login_time, lh.ip_address, 
                                lh.login_attempt, lh.captcha_used,
                                u.full_name as user_full_name
                         FROM LoginHistory lh
                         LEFT JOIN Users u ON lh.user_id = u.user_id
                         WHERE lh.login_time BETWEEN @StartDate AND @EndDate
                         AND (@UserId IS NULL OR lh.user_id = @UserId)
                         AND (@IsSuccess IS NULL OR lh.login_attempt = @IsSuccess)
                         ORDER BY lh.login_time DESC";

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StartDate", startDate);
                command.Parameters.AddWithValue("@EndDate", endDate.AddDays(1)); // Чтобы включить весь последний день
                command.Parameters.AddWithValue("@UserId", userId ?? (object)DBNull.Value);
                command.Parameters.AddWithValue("@IsSuccess", isSuccess ?? (object)DBNull.Value);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        history.Add(new LoginHistoryItem
                        {
                            HistoryId = Convert.ToInt32(reader["history_id"]),
                            LoginTime = Convert.ToDateTime(reader["login_time"]),
                            IpAddress = reader["ip_address"].ToString(),
                            Status = Convert.ToBoolean(reader["login_attempt"]) ? "Успешно" : "Неудачно",
                            CaptchaUsed = Convert.ToBoolean(reader["captcha_used"]),
                            UserFullName = reader["user_full_name"] != DBNull.Value ?
                                          reader["user_full_name"].ToString() : "Неизвестный пользователь"
                        });
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка получения истории входа: {ex.Message}");
                }
            }

            return history;
        }

    }
}