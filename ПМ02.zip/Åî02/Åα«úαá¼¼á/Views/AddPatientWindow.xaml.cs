﻿using MedGorovenko.Models;
using System;
using System.Windows;
using System.Linq;

namespace MedGorovenko.Views
{
    public partial class AddPatientWindow : Window
    {
        public AddPatientWindow()
        {
            InitializeComponent();
            LoadInsuranceCompanies();
            LoadPolicyTypes();
        }

        private void LoadInsuranceCompanies()
        {
            var companies = DatabaseHelper.GetAllInsuranceCompanies();
            InsuranceCompanyComboBox.ItemsSource = companies;
        }

        private void LoadPolicyTypes()
        {
            PolicyTypeComboBox.Items.Add("ОМС");
            PolicyTypeComboBox.Items.Add("ДМС");
            PolicyTypeComboBox.SelectedIndex = 0;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
            this.Close();
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(FullNameTextBox.Text))
            {
                MessageBox.Show("Введите ФИО пациента", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (BirthDatePicker.SelectedDate == null)
            {
                MessageBox.Show("Укажите дату рождения", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(PassportSeriesTextBox.Text) || PassportSeriesTextBox.Text.Length != 4)
            {
                MessageBox.Show("Серия паспорта должна содержать 4 символа", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(PassportNumberTextBox.Text) || PassportNumberTextBox.Text.Length != 6)
            {
                MessageBox.Show("Номер паспорта должен содержать 6 символов", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(PhoneTextBox.Text))
            {
                MessageBox.Show("Введите номер телефона", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(PolicyNumberTextBox.Text))
            {
                MessageBox.Show("Введите номер страхового полиса", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            try
            {
                var newPatient = new Patient
                {
                    FullName = FullNameTextBox.Text,
                    BirthDate = BirthDatePicker.SelectedDate.Value,
                    PassportSeries = PassportSeriesTextBox.Text,
                    PassportNumber = PassportNumberTextBox.Text,
                    Phone = PhoneTextBox.Text,
                    Email = string.IsNullOrWhiteSpace(EmailTextBox.Text) ? null : EmailTextBox.Text,
                    InsurancePolicyNumber = PolicyNumberTextBox.Text,
                    InsurancePolicyType = PolicyTypeComboBox.SelectedItem.ToString(),
                    InsuranceCompanyId = (InsuranceCompanyComboBox.SelectedItem as InsuranceCompany)?.CompanyId
                };

                // Генерируем логин и пароль по умолчанию
                string login = GenerateLogin(newPatient.FullName);
                string password = GeneratePassword();

                newPatient.Login = login;
                newPatient.Password = password; // В реальном проекте нужно хэшировать пароль

                // Сохраняем пациента в базу данных
                DatabaseHelper.AddPatient(newPatient);

                MessageBox.Show("Пациент успешно добавлен", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);

                this.DialogResult = true;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при добавлении пациента: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string GenerateLogin(string fullName)
        {
            // Генерация логина на основе ФИО
            string[] nameParts = fullName.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            if (nameParts.Length >= 3)
            {
                return $"{nameParts[0]}.{nameParts[1][0]}.{nameParts[2][0]}".ToLower();
            }
            else if (nameParts.Length == 2)
            {
                return $"{nameParts[0]}.{nameParts[1][0]}".ToLower();
            }
            else
            {
                return nameParts[0].ToLower();
            }
        }

        private string GeneratePassword()
        {
            // Генерация простого пароля для пациента
            return "password123"; // В реальном проекте нужен более сложный алгоритм
        }
    }
}