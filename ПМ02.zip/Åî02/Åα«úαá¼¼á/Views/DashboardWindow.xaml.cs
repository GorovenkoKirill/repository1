﻿using MedGorovenko.Models;
using MedGorovenko.Views;
using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;

namespace MedGorovenko.Views
{
    public partial class DashboardWindow : Window
    {
        private readonly User _user;
        private DispatcherTimer _sessionTimer;
        private DateTime _sessionEndTime;
        private bool _warningShown = false;

        public DashboardWindow(User user)
        {
            InitializeComponent();
            _user = user;
            DataContext = this;

            // Настраиваем интерфейс в зависимости от роли
            switch (user.Role)
            {
                case UserRole.LabAssistant:
                    LabAssistantPanel.Visibility = Visibility.Visible;
                    break;
                case UserRole.ResearchAssistant:
                    ResearchAssistantPanel.Visibility = Visibility.Visible;
                    break;
                case UserRole.Accountant:
                    AccountantPanel.Visibility = Visibility.Visible;
                    break;
                case UserRole.Administrator:
                    AdminPanel.Visibility = Visibility.Visible;
                    break;
            }

            // Подписываемся на события кнопок
            SubscribeButtons();
        }

        private void SubscribeButtons()
        {
            // Для лаборанта-исследователя
            var workWithAnalyzerBtn = ResearchAssistantPanel.FindName("WorkWithAnalyzerButton") as Button;
            if (workWithAnalyzerBtn != null)
            {
                workWithAnalyzerBtn.Click += WorkWithAnalyzerButton_Click;
            }

            // Для бухгалтера
            var createInvoiceBtn = AccountantPanel.FindName("CreateInvoiceButton") as Button;
            if (createInvoiceBtn != null)
            {
                createInvoiceBtn.Click += CreateInvoiceButton_Click;
            }

        }

        private void WorkWithAnalyzerButton_Click(object sender, RoutedEventArgs e)
        {
            var analyzerWindow = new AnalyzerWindow(_user);
            analyzerWindow.Show();

        }

        private void CreateInvoiceButton_Click(object sender, RoutedEventArgs e)
        {
            var billingWindow = new BillingWindow(_user);
            billingWindow.Show();

        }

        private void ViewReportsButton_Click(object sender, RoutedEventArgs e)
        {
            var reportsWindow = new ReportsWindow(_user);
            reportsWindow.Show();

        }

        private void LogoutButton_Click(object sender, RoutedEventArgs e)
        {
            Logout();
        }

        private void Logout()
        {
            if (_sessionTimer != null)
            {
                _sessionTimer.Stop();
            }

            var loginWindow = new LoginWindow();
            loginWindow.Show();
            this.Close();
        }

        private void AcceptMaterialButton_Click(object sender, RoutedEventArgs e)
        {
            var materialWindow = new MaterialAcceptanceWindow(_user);
            materialWindow.Show();

        }
        public void StartSessionTimer(TimeSpan sessionDuration, TimeSpan warningTime)
        {
            SessionTimerPanel.Visibility = Visibility.Visible;
            _sessionEndTime = DateTime.Now.Add(sessionDuration);

            _sessionTimer = new DispatcherTimer();
            _sessionTimer.Interval = TimeSpan.FromSeconds(1);
            _sessionTimer.Tick += SessionTimer_Tick;
            _sessionTimer.Start();
        }
        private void SessionTimer_Tick(object sender, EventArgs e)  
        {
            var timeLeft = _sessionEndTime - DateTime.Now;
            TimerTextBlock.Text = $"{timeLeft:mm\\:ss}";

            if (timeLeft <= TimeSpan.Zero)
            {
                // Время сеанса истекло
                _sessionTimer.Stop();
                MessageBox.Show("Время сеанса истекло. Система будет заблокирована на 1 минуту.");
                Logout();
            }
            else if (timeLeft <= TimeSpan.FromMinutes(5)) // 5 минут для теста (в реальности 15)
            {
                // Предупреждение о скором окончании сеанса
                if (!_warningShown)
                {
                    MessageBox.Show($"Внимание! До окончания сеанса осталось {timeLeft:mm\\:ss}");
                    _warningShown = true;
                }
            }
        }
    }
}