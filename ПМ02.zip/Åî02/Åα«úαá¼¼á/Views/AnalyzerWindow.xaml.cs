﻿using MedGorovenko.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;
using Newtonsoft.Json;

namespace MedGorovenko.Views
{
    /// <summary>
    /// Логика взаимодействия для AnalyzerWindow.xaml
    /// </summary>
    public partial class AnalyzerWindow : Window
    {
        private readonly User _user;
        private ObservableCollection<Analyzer> _analyzers;
        private ObservableCollection<OrderService> _pendingServices;
        private ObservableCollection<AnalyzerTask> _inProgressTasks;
        private DispatcherTimer _statusCheckTimer;

        public AnalyzerWindow(User user)
        {
            InitializeComponent();
            _user = user;

            _analyzers = new ObservableCollection<Analyzer>(DatabaseHelper.GetAnalyzers());
            AnalyzersComboBox.ItemsSource = _analyzers;

            _pendingServices = new ObservableCollection<OrderService>();
            PendingServicesGrid.ItemsSource = _pendingServices;

            _inProgressTasks = new ObservableCollection<AnalyzerTask>();
            InProgressServicesGrid.ItemsSource = _inProgressTasks;

            _statusCheckTimer = new DispatcherTimer();
            _statusCheckTimer.Interval = TimeSpan.FromSeconds(5);
            _statusCheckTimer.Tick += StatusCheckTimer_Tick;
            _statusCheckTimer.Start();
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedAnalyzer = AnalyzersComboBox.SelectedItem as Analyzer;
            if (selectedAnalyzer != null)
            {
                LoadPendingServices(selectedAnalyzer.AnalyzerId);
            }
        }

        private void LoadPendingServices(int analyzerId)
        {
            _pendingServices.Clear();
            var services = DatabaseHelper.GetPendingServicesForAnalyzer(analyzerId, _user.Id);
            foreach (var service in services)
            {
                _pendingServices.Add(service);
            }
        }

        private async void SendToAnalyzer_Click(object sender, RoutedEventArgs e)
        {
            var selectedService = PendingServicesGrid.SelectedItem as OrderService;
            var selectedAnalyzer = AnalyzersComboBox.SelectedItem as Analyzer;

            if (selectedService == null || selectedAnalyzer == null)
            {
                MessageBox.Show("Выберите услугу и анализатор");
                return;
            }

            // Отправка на анализатор
            try
            {
                var task = new AnalyzerTask
                {
                    OrderServiceId = selectedService.OrderServiceId,
                    AnalyzerId = selectedAnalyzer.AnalyzerId,
                    Status = "Отправлено",
                    StartTime = DateTime.Now
                };

                // Отправка HTTP запроса к анализатору
                var result = await SendToAnalyzerAsync(selectedAnalyzer.Name, selectedService);

                if (result)
                {
                    // Обновляем статус в базе
                    DatabaseHelper.UpdateServiceStatus(selectedService.OrderServiceId, "В процессе");

                    // Добавляем в список выполняющихся задач
                    _inProgressTasks.Add(task);
                    _pendingServices.Remove(selectedService);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка отправки на анализатор: {ex.Message}");
            }
        }

        private async Task<bool> SendToAnalyzerAsync(string analyzerName, OrderService service)
        {
            using (var client = new HttpClient())
            {
                var request = new
                {
                    patient = service.OrderId.ToString(),
                    services = new[] { new { serviceCode = service.ServiceId } }
                };

                var content = new StringContent(JsonConvert.SerializeObject(request),
                    Encoding.UTF8, "application/json");

                var response = await client.PostAsync(
                    $"http://localhost:5000/api/analyzer/{analyzerName}", content);

                return response.IsSuccessStatusCode;
            }
        }

        private async void StatusCheckTimer_Tick(object sender, EventArgs e)
        {
            foreach (var task in _inProgressTasks.ToList())
            {
                try
                {
                    var status = await GetAnalyzerStatusAsync(task.AnalyzerId, task.OrderServiceId);

                    if (status.IsCompleted)
                    {
                        task.Result = status.Result;
                        task.Status = "Завершено";

                        // Проверка на отклонение от нормы
                        if (IsResultAbnormal(task))
                        {
                            MessageBox.Show("Результат значительно отклоняется от нормы. Проверьте корректность исследования.");
                        }
                    }
                    else
                    {
                        task.Progress = status.Progress;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка проверки статуса: {ex.Message}");
                }
            }
        }

        private async Task<AnalyzerStatus> GetAnalyzerStatusAsync(int analyzerId, int orderServiceId)
        {
            var analyzer = _analyzers.FirstOrDefault(a => a.AnalyzerId == analyzerId);
            if (analyzer == null) return new AnalyzerStatus { IsCompleted = false };

            using (var client = new HttpClient())
            {
                var response = await client.GetAsync(
                    $"http://localhost:5000/api/analyzer/{analyzer.Name}");

                if (response.IsSuccessStatusCode)
                {
                    var content = await response.Content.ReadAsStringAsync();
                    var result = JsonConvert.DeserializeObject<dynamic>(content);

                    if (result.progress != null)
                    {
                        return new AnalyzerStatus
                        {
                            IsCompleted = false,
                            Progress = result.progress
                        };
                    }
                    else
                    {
                        return new AnalyzerStatus
                        {
                            IsCompleted = true,
                            Result = result.services[0].result
                        };
                    }
                }
            }

            return new AnalyzerStatus { IsCompleted = false };
        }

        private bool IsResultAbnormal(AnalyzerTask task)
        {
            var service = DatabaseHelper.GetServiceById(task.ServiceId);
            if (service.AverageDeviation == null) return false;

            decimal resultValue;
            if (decimal.TryParse(task.Result, out resultValue))
            {
                return Math.Abs(resultValue) > service.AverageDeviation * 5;
            }

            return false;
        }

        private void ApproveResult_Click(object sender, RoutedEventArgs e)
        {
            var task = InProgressServicesGrid.SelectedItem as AnalyzerTask;
            if (task != null)
            {
                DatabaseHelper.UpdateServiceStatus(task.OrderServiceId, "Завершено", task.Result);
                _inProgressTasks.Remove(task);
            }
        }

        private void RejectResult_Click(object sender, RoutedEventArgs e)
        {
            var task = InProgressServicesGrid.SelectedItem as AnalyzerTask;
            if (task != null)
            {
                DatabaseHelper.UpdateServiceStatus(task.OrderServiceId, "Требуется повтор");
                _inProgressTasks.Remove(task);
            }
        }
    }

    public class AnalyzerTask
    {
        public int OrderServiceId { get; set; }
        public int AnalyzerId { get; set; }
        public int ServiceId { get; set; }
        public string Status { get; set; }
        public int Progress { get; set; }
        public string Result { get; set; }
        public DateTime StartTime { get; set; }
        public string PatientName { get; set; }
        public string ServiceName { get; set; }
        public string Code { get; set; }
    }

    public class AnalyzerStatus
    {
        public bool IsCompleted { get; set; }
        public int Progress { get; set; }
        public string Result { get; set; }
    }
}
