﻿using MedGorovenko.Models;
using Microsoft.Win32;
using System;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Windows;
//using System.Windows.Forms;
using MessageBox = System.Windows.MessageBox;

namespace MedGorovenko.Views
{
    public partial class ReportsWindow : Window
    {
        private readonly User _user;
        public ObservableCollection<InsuranceCompany> Companies { get; set; }
        public ObservableCollection<BillingReportItem> ReportItems { get; set; }

        public ReportsWindow(User user)
        {
            InitializeComponent();
            _user = user;
            DataContext = this;

            Companies = new ObservableCollection<InsuranceCompany>();
            ReportItems = new ObservableCollection<BillingReportItem>();

            LoadCompanies();
            SetDefaultDates();
            LoadReportData();
        }

        private void LoadCompanies()
        {
            Companies.Clear();
            var companies = DatabaseHelper.GetAllInsuranceCompanies();
            foreach (var company in companies)
            {
                Companies.Add(company);
            }

            CompanyComboBox.ItemsSource = Companies;
            if (Companies.Any())
            {
                CompanyComboBox.SelectedIndex = 0;
            }
        }

        private void SetDefaultDates()
        {
            StartDatePicker.SelectedDate = DateTime.Today.AddMonths(-1);
            EndDatePicker.SelectedDate = DateTime.Today;
        }

        private void LoadReportData()
        {
            try
            {
                ReportItems.Clear();

                var selectedCompany = CompanyComboBox.SelectedItem as InsuranceCompany;
                var startDate = StartDatePicker.SelectedDate ?? DateTime.Today.AddMonths(-1);
                var endDate = EndDatePicker.SelectedDate ?? DateTime.Today;

                var reportData = DatabaseHelper.GetBillingReportData(
                    selectedCompany?.CompanyId,
                    startDate,
                    endDate);

                foreach (var item in reportData)
                {
                    ReportItems.Add(item);
                }

                ReportsDataGrid.ItemsSource = ReportItems;
                UpdateTotal();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateTotal()
        {
            decimal total = ReportItems.Sum(item => item.Price);
            TotalTextBlock.Text = $"Итого: {total:C}";
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadReportData();
        }

        private void ExportToExcel_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var saveFileDialog = new SaveFileDialog
                {
                    Filter = "Excel Files|*.xlsx",
                    Title = "Сохранить отчет в Excel",
                    FileName = $"Отчет_{DateTime.Now:yyyyMMdd}.xlsx"
                };

                //if (saveFileDialog.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                //{
                //    // Здесь должна быть логика экспорта в Excel
                //    // Например, с использованием библиотеки EPPlus или ClosedXML

                //    MessageBox.Show($"Отчет успешно сохранен: {saveFileDialog.FileName}",
                //        "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка экспорта в Excel: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }

    public class BillingReportItem
    {
        public DateTime Date { get; set; }
        public string CompanyName { get; set; }
        public string PatientName { get; set; }
        public string ServiceName { get; set; }
        public decimal Price { get; set; }
    }
}