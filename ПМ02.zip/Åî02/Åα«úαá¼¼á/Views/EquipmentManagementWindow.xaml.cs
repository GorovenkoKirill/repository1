﻿using MedGorovenko.Models;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace MedGorovenko.Views
{
    public partial class EquipmentManagementWindow : Window
    {
        public ObservableCollection<Analyzer> Analyzers { get; set; } = new ObservableCollection<Analyzer>();

        public EquipmentManagementWindow()
        {
            InitializeComponent();
            DataContext = this;
            LoadAnalyzers();
        }

        private void LoadAnalyzers(bool showInactive = false)
        {
            Analyzers.Clear();
            var analyzers = DatabaseHelper.GetAnalyzers(showInactive);
            foreach (var analyzer in analyzers)
            {
                Analyzers.Add(analyzer);
            }
            EquipmentDataGrid.ItemsSource = Analyzers;
        }

        private void AddEquipmentButton_Click(object sender, RoutedEventArgs e)
        {
            var addEquipmentWindow = new AddEditEquipmentWindow();
            if (addEquipmentWindow.ShowDialog() == true)
            {
                LoadAnalyzers(ShowInactiveCheckBox.IsChecked ?? false);
            }
        }
            
        private void EditEquipmentButton_Click(object sender, RoutedEventArgs e)
        {
            if (EquipmentDataGrid.SelectedItem is Analyzer selectedAnalyzer)
            {
                var editEquipmentWindow = new AddEditEquipmentWindow(selectedAnalyzer);
                if (editEquipmentWindow.ShowDialog() == true)
                {
                    LoadAnalyzers(ShowInactiveCheckBox.IsChecked ?? false);
                }
            }
            else
            {
                MessageBox.Show("Выберите оборудование для редактирования", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DeleteEquipmentButton_Click(object sender, RoutedEventArgs e)
        {
            if (EquipmentDataGrid.SelectedItem is Analyzer selectedAnalyzer)
            {
                var result = MessageBox.Show($"Вы уверены, что хотите удалить оборудование {selectedAnalyzer.Name}?",
                    "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        DatabaseHelper.DeleteAnalyzer(selectedAnalyzer.AnalyzerId);
                        LoadAnalyzers(ShowInactiveCheckBox.IsChecked ?? false);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении оборудования: {ex.Message}", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите оборудование для удаления", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            var searchText = SearchTextBox.Text.Trim();
            if (string.IsNullOrEmpty(searchText))
            {
                LoadAnalyzers(ShowInactiveCheckBox.IsChecked ?? false);
                return;
            }

            Analyzers.Clear();
            var filteredAnalyzers = DatabaseHelper.SearchAnalyzers(searchText);
            foreach (var analyzer in filteredAnalyzers)
            {
                Analyzers.Add(analyzer);
            }
        }

        private void ShowInactiveCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            LoadAnalyzers(true);
        }

        private void ShowInactiveCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            LoadAnalyzers(false);
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadAnalyzers(ShowInactiveCheckBox.IsChecked ?? false);
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}