﻿using MedGorovenko.Models;
using System.Windows;
using System.Windows.Controls;
using System.Collections.ObjectModel;

namespace MedGorovenko.Views
{
    public partial class MaterialAcceptanceWindow : Window
    {
        public User User { get; set; }
        public ObservableCollection<Order> Orders { get; set; }

        public MaterialAcceptanceWindow(User user)
        {
            InitializeComponent();
            User = user;
            DataContext = this;

            LoadOrders();
        }

        private void LoadOrders()
        {
            // Загрузка заказов из базы данных
            Orders = new ObservableCollection<Order>(DatabaseHelper.GetActiveOrdersWithServices());

            // Если нужно показать пустое состояние при первом открытии
            if (Orders.Count > 0)
            {
                OrdersListView.SelectedIndex = 0;
            }
        }

        private void OrdersListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (OrdersListView.SelectedItem is Order selectedOrder)
            {
                // Обновляем детали заказа
                ShowOrderDetails(selectedOrder);
            }
            else
            {
                OrderContentControl.Content = null;
            }
        }

        private void ShowOrderDetails(Order order)
        {
            // Проверяем, нужно ли обновлять содержимое
            if (OrderContentControl.Content is OrderDetailsView existingView)
            {
                if (existingView.DataContext == order) return;
            }

            // Создаем новое представление деталей заказа
            var orderDetailsView = new OrderDetailsView(order);
            OrderContentControl.Content = orderDetailsView;
        }

        private void NewOrderButton_Click(object sender, RoutedEventArgs e)
        {
            var newOrderWindow = new NewOrderWindow(User);
            if (newOrderWindow.ShowDialog() == true)
            {
                // Обновляем список заказов
                LoadOrders();

                // Выбираем последний добавленный заказ
                if (Orders.Count > 0)
                {
                    OrdersListView.SelectedItem = Orders[Orders.Count - 1];
                }
            }
        }
    }
}