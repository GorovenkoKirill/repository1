﻿using MedGorovenko.Models;
using System;
using System.Windows;
using System.Collections.ObjectModel;
using System.Linq;

namespace MedGorovenko.Views
{
    public partial class BillingWindow : Window
    {
        private readonly User _user;
        public ObservableCollection<InsuranceCompany> InsuranceCompanies { get; set; }
        public ObservableCollection<BillingData> BillingItems { get; set; }

        public BillingWindow(User user)
        {
            InitializeComponent();
            DataContext = this;
            _user = user;

            InsuranceCompanies = new ObservableCollection<InsuranceCompany>();
            BillingItems = new ObservableCollection<BillingData>();

            LoadInsuranceCompanies();

            // Установка дат по умолчанию
            StartDatePicker.SelectedDate = DateTime.Today.AddMonths(-1);
            EndDatePicker.SelectedDate = DateTime.Today;
        }

        private void LoadInsuranceCompanies()
        {
            var companies = DatabaseHelper.GetAllInsuranceCompanies();
            InsuranceCompanies.Clear();
            foreach (var company in companies)
            {
                InsuranceCompanies.Add(company);
            }

            if (InsuranceCompanies.Any())
            {
                InsuranceCompanyComboBox.SelectedIndex = 0;
            }
        }

        private void GeneratePdfButton_Click(object sender, RoutedEventArgs e)
        {
            // Ваш код генерации PDF
            MessageBox.Show("PDF сформирован");
        }

        private void GenerateCsvButton_Click(object sender, RoutedEventArgs e)
        {
            // Ваш код генерации CSV
            MessageBox.Show("CSV сформирован");
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}