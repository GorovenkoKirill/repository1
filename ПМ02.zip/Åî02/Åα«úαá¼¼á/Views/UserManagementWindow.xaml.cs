﻿using MedGorovenko.Models;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace MedGorovenko.Views
{
    public partial class UserManagementWindow : Window
    {
        public ObservableCollection<User> Users { get; set; } = new ObservableCollection<User>();

        public UserManagementWindow()
        {
            InitializeComponent();
            DataContext = this;
            LoadUsers();
        }

        private void LoadUsers()
        {
            Users.Clear();
            var users = DatabaseHelper.GetAllUsers();
            foreach (var user in users)
            {
                Users.Add(user);
            }
            UsersDataGrid.ItemsSource = Users;
        }

        private void AddUserButton_Click(object sender, RoutedEventArgs e)
        {
            var addUserWindow = new AddEditUserWindow();
            if (addUserWindow.ShowDialog() == true)
            {
                LoadUsers(); // Обновляем список после добавления
            }
        }

        private void EditUserButton_Click(object sender, RoutedEventArgs e)
        {
            if (UsersDataGrid.SelectedItem is User selectedUser)
            {
                var editUserWindow = new AddEditUserWindow(selectedUser);
                if (editUserWindow.ShowDialog() == true)
                {
                    LoadUsers(); // Обновляем список после редактирования
                }
            }
            else
            {
                MessageBox.Show("Выберите пользователя для редактирования", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void DeleteUserButton_Click(object sender, RoutedEventArgs e)
        {
            if (UsersDataGrid.SelectedItem is User selectedUser)
            {
                var result = MessageBox.Show($"Вы уверены, что хотите удалить пользователя {selectedUser.FullName}?",
                    "Подтверждение удаления", MessageBoxButton.YesNo, MessageBoxImage.Question);

                if (result == MessageBoxResult.Yes)
                {
                    try
                    {
                        DatabaseHelper.DeleteUser(selectedUser.Id);
                        LoadUsers(); // Обновляем список после удаления
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при удалении пользователя: {ex.Message}", "Ошибка",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Выберите пользователя для удаления", "Внимание",
                    MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        private void SearchButton_Click(object sender, RoutedEventArgs e)
        {
            var searchText = SearchTextBox.Text.Trim();
            if (string.IsNullOrEmpty(searchText))
            {
                LoadUsers();
                return;
            }

            Users.Clear();
            var filteredUsers = DatabaseHelper.SearchUsers(searchText);
            foreach (var user in filteredUsers)
            {
                Users.Add(user);
            }
        }

        private void RefreshButton_Click(object sender, RoutedEventArgs e)
        {
            LoadUsers();
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}