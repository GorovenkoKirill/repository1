﻿using MedGorovenko.Models;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;

namespace MedGorovenko.Views
{
    public partial class ActivityLogWindow : Window
    {
        public ObservableCollection<LoginHistoryItem> LoginHistory { get; set; } = new ObservableCollection<LoginHistoryItem>();
        public ObservableCollection<User> Users { get; set; } = new ObservableCollection<User>();

        public ActivityLogWindow()
        {
            InitializeComponent();
            DataContext = this;

            // Устанавливаем даты по умолчанию (последние 7 дней)
            EndDatePicker.SelectedDate = DateTime.Today;
            StartDatePicker.SelectedDate = DateTime.Today.AddDays(-7);

            LoadUsers();
            LoadLoginHistory();
        }

        private void LoadUsers()
        {
            Users.Clear();
            var users = DatabaseHelper.GetAllUsers();
            foreach (var user in users)
            {
                Users.Add(user);
            }

            UserComboBox.ItemsSource = Users;
            UserComboBox.Items.Insert(0, new User { FullName = "Все пользователи" });
            UserComboBox.SelectedIndex = 0;
        }

        private void LoadLoginHistory()
        {
            LoginHistory.Clear();

            var startDate = StartDatePicker.SelectedDate ?? DateTime.Today.AddDays(-7);
            var endDate = EndDatePicker.SelectedDate ?? DateTime.Today;

            var selectedUser = UserComboBox.SelectedItem as User;
            int? userId = selectedUser?.Id > 0 ? selectedUser.Id : (int?)null;

            bool? successStatus = null;
            if (StatusComboBox.SelectedIndex == 1) successStatus = true;
            else if (StatusComboBox.SelectedIndex == 2) successStatus = false;

            var history = DatabaseHelper.GetLoginHistory(startDate, endDate, userId, successStatus);

            foreach (var item in history)
            {
                LoginHistory.Add(item);
            }

            ActivityDataGrid.ItemsSource = LoginHistory;
            UpdateStatistics();
        }

        private void UpdateStatistics()
        {
            TotalRecordsText.Text = LoginHistory.Count.ToString();
            SuccessfulLoginsText.Text = LoginHistory.Count(x => x.Status == "Успешно").ToString();
            FailedLoginsText.Text = LoginHistory.Count(x => x.Status == "Неудачно").ToString();
            CaptchaUsedText.Text = LoginHistory.Count(x => x.CaptchaUsed).ToString();
        }

        private void ApplyFiltersButton_Click(object sender, RoutedEventArgs e)
        {
            LoadLoginHistory();
        }
    }
}