﻿using MedGorovenko.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;

namespace MedGorovenko.Views
{
    public partial class AddEditUserWindow : Window
    {
        public User User { get; set; }
        public string WindowTitle { get; set; }
        public Dictionary<UserRole, string> Roles { get; set; }

        public AddEditUserWindow()
        {
            InitializeComponent();
            WindowTitle = "Добавление нового пользователя";
            User = new User();
            InitializeRoles();
            DataContext = this;
        }

        public AddEditUserWindow(User userToEdit)
        {
            InitializeComponent();
            WindowTitle = "Редактирование пользователя";
            User = userToEdit;
            InitializeRoles();
            DataContext = this;
        }

        private void InitializeRoles()
        {
            Roles = new Dictionary<UserRole, string>
            {
                { UserRole.LabAssistant, "Лаборант" },
                { UserRole.ResearchAssistant, "Лаборант-исследователь" },
                { UserRole.Accountant, "Бухгалтер" },
                { UserRole.Administrator, "Администратор" }
            };
            RoleComboBox.ItemsSource = Roles;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(User.Login))
            {
                MessageBox.Show("Введите логин пользователя", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            if (string.IsNullOrWhiteSpace(User.FullName))
            {
                MessageBox.Show("Введите ФИО пользователя", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Если это добавление нового пользователя или изменение пароля
            if (User.Id == 0 || !string.IsNullOrEmpty(PasswordBox.Password))
            {
                if (PasswordBox.Password != ConfirmPasswordBox.Password)
                {
                    MessageBox.Show("Пароли не совпадают", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (PasswordBox.Password.Length < 6)
                {
                    MessageBox.Show("Пароль должен содержать не менее 6 символов", "Ошибка",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                User.Password = PasswordBox.Password; // В реальном проекте нужно хэшировать пароль
            }

            try
            {
                if (User.Id == 0)
                {
                    // Добавление нового пользователя
                    DatabaseHelper.AddUser(User);
                }
                else
                {
                    // Обновление существующего пользователя
                    DatabaseHelper.UpdateUser(User);
                }

                DialogResult = true;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении пользователя: {ex.Message}", "Ошибка",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}