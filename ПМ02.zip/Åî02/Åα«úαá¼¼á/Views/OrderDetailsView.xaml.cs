﻿using MedGorovenko.Models;
using System.Windows;
using System.Windows.Controls;

namespace MedGorovenko.Views
{
    public partial class OrderDetailsView : UserControl
    {
        public OrderDetailsView(Order order)
        {
            InitializeComponent();
            DataContext = order;
        }

        private void PrintBarcode_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is Order order)
            {
                MessageBox.Show($"Печать штрих-кода: {order.Barcode}",
                                "Печать",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
                // Здесь можно добавить реальную логику печати
            }
        }

        private void ChangeStatus_Click(object sender, RoutedEventArgs e)
        {
            if (DataContext is Order order)
            {
                // Здесь можно добавить логику изменения статуса
                MessageBox.Show($"Изменение статуса заказа {order.OrderId}",
                                "Статус",
                                MessageBoxButton.OK,
                                MessageBoxImage.Information);
            }
        }
    }
}